//=============================================================================
// main.js
//=============================================================================

(() => {
    const startTime = performance.now();
    const endTime = () => `${((performance.now() - startTime) / 1e3).toPrecision(3)}s`;

    let isMobileDevice = () => {
        let isMobile = false;
        if (navigator.userAgentData?.mobile != null) {
            isMobile = navigator.userAgentData.mobile ? true : false;
        } else if (window.matchMedia?.('(max-width: 767px), (pointer: coarse)')?.matches) {
            isMobile = true;
        } else if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            isMobile = true;
        }
        isMobileDevice = () => isMobile;
        return isMobile;
    };

    let scriptReload = (() => {
        const basePath =
            isMobileDevice()
                ? window.cdvUrl
                : (() => {
                    const path = require('path');
                    return path.join(process.cwd(), "www");
                })();

        function joinPath(base, p) {
            if (!base) return p || '';
            if (!p) return base.replace(/\/+$/, '');
            return base.replace(/\/+$/, '') + '/' + p.replace(/^\/+/, '');
        };

        function fileExists(filePath) {
            return new Promise(resolve => {
                if (isMobileDevice()) {
                    if (!filePath) return resolve(false);
                    const url = joinPath(basePath, filePath);
                    window.resolveLocalFileSystemURL(url,
                        () => resolve(true),
                        () => resolve(false)
                    );
                }
                else {
                    const fs = require('fs');
                    const path = require('path');
                    try {
                        if (!path.isAbsolute(filePath))
                            filePath = path.join(basePath, filePath);
                        resolve(fs.existsSync(filePath));
                    } catch (e) {
                        resolve(false);
                    }
                }
            });
        };

        /**
         * @param {Element} script - 錯誤的 script 元素
         * @param {String} src - 載入的 src
         * @param {Number|Undefined} retries - 重載次數
         * @returns {Promise} - 重試狀態
         */
        function reTry(script, src, retries = 5) {
            return new Promise(async (resolve, reject) => {
                if (!await fileExists(src) || !script) return reject();

                // ? 不採用直接替換 src 的原因是, 無法正確觸發新的 onload 或 onerror 事件
                script.remove(); // 刪除錯誤對象
                script = document.createElement('script'); // 創建一個新的

                // 存在時觸發重載
                Object.assign(script, {
                    src,
                    onload: resolve,
                    onerror() {
                        if (retries <= 0) {
                            script.remove();
                            return reject();
                        }
                        setTimeout(() => {
                            reTry(script, src, retries - 1)
                                .then(resolve)
                                .catch(reject)
                        }, 100);
                    }
                })

                document.head.appendChild(script);
            })
        };

        return { reTry };
    })();

    let loadScript = (() => {
        function createScript(src) {
            return new Promise((resolve, reject) => {
                document.head.appendChild(
                    Object.assign(document.createElement('script'), {
                        src,
                        onload: resolve,
                        onerror() {
                            scriptReload.reTry(this, src)
                                .then(resolve)
                                .catch(() => reject(`Error load: ${src}`))
                        }
                    })
                )
            })
        };

        return {
            seq(list) {
                return list.reduce((promise, src) => {
                    return promise.then(() => createScript(src));
                }, Promise.resolve());
            }
        }
    })();

    let init = (() => {
        const pixiList = [
            'js/libs/pixi.js',
            'js/libs/pixi-tilemap.js',
            'js/libs/pixi-picture.js',
        ];
        const otherList = [
            'js/libs/lz-string.js',
            'js/libs/iphone-inline-video.browser.js',
        ];
        const rpgCoreList = [
            'js/rpg_core.js',
            'js/rpg_managers.js',
            'js/rpg_objects.js',
            'js/rpg_scenes.js',
            'js/rpg_sprites.js',
            'js/rpg_windows.js',
            'js/rpg_custom.js',
            'js/plugins.js',
        ];

        const openCC = 'js/libs/opencc/full.min.js';

        /* Android */
        const cordova = 'cordova.js';

        function loadPlugins() {
            Object.assign(PluginManager, {
                scriptRecord: null,
                setup(plugins) {
                    this.scriptRecord = new Set(this._scripts);

                    if (isMobileDevice()) this._path = window.cdvUrl + this._path;

                    loadScript.seq(
                        plugins.map(plugin => {
                            if (plugin.status && !this.scriptRecord.has(plugin.name)) {
                                this.setParameters(plugin.name, plugin.parameters);
                                this.scriptRecord.add(plugin.name);
                                return this._path + plugin.name + '.js';
                            }
                        }).filter(Boolean)
                    ).then(() => {
                        SceneManager.run(Scene_Boot);
                        console.log('[OK] Init Complete', endTime());
                    }).catch(err => {
                        console.error(err);
                    }).finally(() => {
                        this._scripts = [...this.scriptRecord];
                        this.scriptRecord.clear();
                    })
                }
            });

            PluginManager.setup($plugins);
        };

        return {
            android() {
                function onDeviceReady() {
                    const root = cordova.file && cordova.file.dataDirectory;
                    if (!root || !window.resolveLocalFileSystemURL) {
                        console.error('cordova.file.dataDirectory or resolveLocalFileSystemURL not available');
                        return;
                    }

                    window.resolveLocalFileSystemURL(root, entry => {
                        try {
                            window.cdvUrl = (typeof entry.toInternalURL === 'function') ? entry.toInternalURL() : (entry.nativeURL || root);
                        } catch (e) {
                            window.cdvUrl = entry.nativeURL || root;
                        }

                        // ensure trailing slash
                        if (window.cdvUrl && !window.cdvUrl.endsWith('/')) window.cdvUrl += '/';
                        console.log('Global cdvUrl =', window.cdvUrl);

                        loadScript.seq([
                            ...[
                                ...pixiList,
                                ...otherList,
                                ...rpgCoreList,
                            ].map(path => window.cdvUrl + path)
                        ]).then(() => {
                            loadPlugins();
                            console.log('[OK] Android scripts loaded via seq', endTime());
                        }).catch(err => {
                            console.error('[ERR] Android seq load error:', err);
                        }).finally(() => {
                            scriptReload = null;
                            loadScript = null;
                            init = null;
                        })

                    }, err => {
                        console.error('Error load FileEntry:', err);
                        scriptReload = null;
                        loadScript = null;
                        init = null;
                    });
                }

                const script = document.createElement('script');
                script.src = cordova;
                script.onload = () => {
                    window.device
                        ? onDeviceReady()
                        : document.addEventListener('deviceready', onDeviceReady, { once: true });
                };
                document.head.appendChild(script);
            },
            // —— Desktop / NW.js —— 
            desktop() {
                loadScript.seq([...pixiList, ...otherList, openCC, ...rpgCoreList])
                    .then(() => {
                        loadPlugins();
                        console.log('[OK] Desktop scripts loaded', endTime());
                    }).catch(err => {
                        console.error(err);
                    }).finally(() => {
                        // 釋放閉包 GC
                        scriptReload = null;
                        loadScript = null;
                        init = null;
                    })
            }
        }
    })();

    isMobileDevice()
        ? init.android()
        : init.desktop();
})();