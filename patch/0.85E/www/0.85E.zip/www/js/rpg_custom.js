(() => {
    // 手机版补丁
    if (!Utils.isMobileDevice()) return;

    // ========== rpg_core.js ==========

    // 确保能够读取自动更新的json、png、ogg文件
    WebAudio.prototype._load = function (url) {
        if (!WebAudio._context) return;
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var firstUrl = Decrypter.hasEncryptedAudio
            ? Decrypter.extToEncryptExt(url)
            : url;
        var dataFull = dataBase + firstUrl;
        var originalRequest = function () {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", firstUrl);
            xhr.responseType = "arraybuffer";
            xhr.onload = function () {
                if (xhr.status < 400) {
                    this._onXhrLoad(xhr);
                }
            }.bind(this);
            xhr.onerror = this._loader || function () { this._hasError = true; }.bind(this);
            xhr.send();
        }.bind(this);

        window.resolveLocalFileSystemURL(
            dataFull,
            function (entry) {
                entry.file(function (file) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        //console.log("[WebAudio] Loaded from dataDirectory:", dataFull);
                        var fakeXhr = { response: reader.result };
                        this._onXhrLoad(fakeXhr);
                    }.bind(this);
                    reader.onerror = originalRequest;
                    reader.readAsArrayBuffer(file);
                }.bind(this), originalRequest);
            }.bind(this),
            originalRequest
        );
    };

    Bitmap.prototype._requestImage = function (url) {
        if (Bitmap._reuseImages.length !== 0) {
            this._image = Bitmap._reuseImages.pop();
        } else { this._image = new Image(); }
        if (this._decodeAfterRequest && !this._loader) {
            this._loader = ResourceHandler.createLoader(
                url,
                this._requestImage.bind(this, url),
                this._onError.bind(this)
            );
        }
        this._url = url;
        this._loadingState = 'requesting';

        // ===== check for image encryption =====
        if (!Decrypter.checkImgIgnore(url) && Decrypter.hasEncryptedImages) {
            this._loadingState = 'decrypting';
            Decrypter.decryptImg(url, this);
            return;
        }

        // ===== use of unencrypted images =====
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var dataFull = dataBase + url;
        var originalLoad = function () {
            this._image.src = url;
            this._image.addEventListener(
                'load',
                this._loadListener = Bitmap.prototype._onLoad.bind(this)
            );
            this._image.addEventListener(
                'error',
                this._errorListener = this._loader || Bitmap.prototype._onError.bind(this)
            );
        }.bind(this);
        var tryLocal = function (path, onSuccess, onFail) {
            window.resolveLocalFileSystemURL(
                path,
                function (entry) {
                    entry.file(function (file) {
                        var reader = new FileReader();
                        reader.onload = function () {
                            //console.log('[Bitmap] Loaded from dataDirectory:', path);
                            var blob = new Blob([reader.result]);
                            this._image.src = URL.createObjectURL(blob);
                            this._image.addEventListener(
                                'load',
                                this._loadListener = Bitmap.prototype._onLoad.bind(this)
                            );
                            this._image.addEventListener(
                                'error',
                                this._errorListener = this._loader || Bitmap.prototype._onError.bind(this)
                            );
                        }.bind(this);
                        reader.onerror = onFail;
                        reader.readAsArrayBuffer(file);
                    }.bind(this), onFail);
                }.bind(this),
                onFail
            );
        }.bind(this);
        tryLocal(
            dataFull,
            function () {
            },
            originalLoad
        );
    };

    Decrypter.decryptImg = function (url, bitmap) {
        var relativeUrl = this.extToEncryptExt(url);
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var dataFull = dataBase + relativeUrl;
        function originalRequest() {
            var req = new XMLHttpRequest();
            req.open("GET", relativeUrl);
            req.responseType = "arraybuffer";
            req.send();
            req.onload = function () {
                if (this.status < Decrypter._xhrOk) {
                    var decrypted = Decrypter.decryptArrayBuffer(req.response);
                    bitmap._image.src = Decrypter.createBlobUrl(decrypted);
                    bitmap._image.addEventListener(
                        "load",
                        bitmap._loadListener = Bitmap.prototype._onLoad.bind(bitmap)
                    );
                    bitmap._image.addEventListener(
                        "error",
                        bitmap._errorListener = bitmap._loader || Bitmap.prototype._onError.bind(bitmap)
                    );
                } else {
                    if (bitmap._loader) bitmap._loader();
                    else bitmap._onError();
                }
            };
            req.onerror = function () {
                if (bitmap._loader) bitmap._loader();
                else bitmap._onError();
            };
        }
        window.resolveLocalFileSystemURL(
            dataFull,
            function (entry) {
                entry.file(function (file) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        //console.log("[Decrypter] Loaded from dataDirectory:", dataFull);
                        var decrypted = Decrypter.decryptArrayBuffer(reader.result);
                        bitmap._image.src = Decrypter.createBlobUrl(decrypted);
                        bitmap._image.addEventListener(
                            "load",
                            bitmap._loadListener = Bitmap.prototype._onLoad.bind(bitmap)
                        );
                        bitmap._image.addEventListener(
                            "error",
                            bitmap._errorListener = bitmap._loader || Bitmap.prototype._onError.bind(bitmap)
                        );
                    };
                    reader.onerror = function () {
                        originalRequest();
                    };
                    reader.readAsArrayBuffer(file);
                }, function () {
                    originalRequest();
                });
            },
            function () {
                originalRequest();
            }
        );
    };

    // ========== rpg_managers.js ==========

    // 在外部读写游戏文件
    Object.assign(DataManager, {
        loadDataFile(name, src) {
            var xhr = new XMLHttpRequest();
            var url = window.cdvUrl + 'data/' + src;
            xhr.open('GET', url);
            xhr.overrideMimeType('application/json');
            xhr.onload = function () {
                if (xhr.status < 400) {
                    window[name] = JSON.parse(xhr.responseText);
                    DataManager.onLoad(window[name]);
                }
            };
            xhr.onerror = this._mapLoader || function () {
                DataManager._errorUrl = DataManager._errorUrl || url;
            };
            window[name] = null;
            xhr.send();
        },
        loadMapData(mapId) {
            if (mapId > 0) {
                var filename = 'Map%1.json'.format(mapId.padZero(3));
                this._mapLoader = ResourceHandler.createLoader(window.cdvUrl + 'data/' + filename, this.loadDataFile.bind(this, '$dataMap', filename));
                this.loadDataFile('$dataMap', filename);
            } else {
                this.makeEmptyMap();
            }
        }
    });

    Object.assign(StorageManager, {
        loadFromWebStorage(savefileId) {
            var data = null;
            var filePath = this.localFilePath(savefileId);
            data = AndroidSave.loadSave(filePath);
            return data;
        },
        saveToWebStorage(savefileId, json) {
            var filePath = this.localFilePath(savefileId);
            AndroidSave.saveGame(filePath, json);
        },
        removeWebStorage(savefileId) {
            var filePath = this.localFilePath(savefileId);
            AndroidSave.removeSave(filePath);
        },
        webStorageExists(savefileId) {
            var fileName = this.localFilePath(savefileId);
            return AndroidSave.loadSaveExists(fileName);
        },
        localFilePath(savefileId) {
            let name;
            if (savefileId < 0) {
                name = 'config.rpgsave';
            } else if (savefileId === 0) {
                name = 'global.rpgsave';
            } else {
                name = 'file%1.rpgsave'.format(savefileId);
            }
            return name;
        }
    })
})();

(() => {
    const originalPop = SceneManager.pop;
    Object.defineProperty(window, 'checkModify', {
        get() {
            return originalPop !== SceneManager.pop;
        }
    });

    // ========== rpg_managers.js ==========

    let getVersion = () => {
        let ver = "";
        // 1) 从 System 标题里解析 “verX.X.X”
        if ($dataSystem && $dataSystem.gameTitle) {
            const m = $dataSystem.gameTitle.match(/ver\s*([A-Za-z0-9._-]+)/i);
            if (m) ver = m[1];
        };

        // 2) 兜底：从 document.title 里再试一次
        if (!ver && document.title) {
            const m2 = document.title.match(/ver\s*([A-Za-z0-9._-]+)/i);
            if (m2) ver = m2[1];
        };

        // 设备标记
        const suffix = (window.Utils && Utils.isMobileDevice()) ? " (Android)" : "";
        const result = `Current Version: ${ver || ""}${suffix}`;

        getVersion = () => result;
        return result;
    };

    Object.assign(Graphics, {
        backupPrintError: Graphics.printError, // 避免被覆蓋
        _makeErrorHtml(name = "UnknownError", error = {}) {

            // 自动上传bug报告到服务器上

            // 合并 stack 与 message
            const rawStack = error?.stack || "";
            const rawMessage = error?.message || "";

            if (navigator.onLine && appScript) {
                let combined = `${rawMessage}\n${rawStack}`;

                // 截断超长文本，避免单元格超限
                const MAX = 2000;
                if (combined.length > MAX) combined = combined.slice(0, MAX) + "\n...[truncated]";

                let mapId;
                if ($gameMap && $gameMap.mapId) {
                    const gmID = $gameMap.mapId?.();
                    mapId = gmID || gmID === 0
                        ? gmID : "Unknown";
                };
                let isMtool = !!window.checkModify;
                const payload = {
                    version: getVersion(),
                    errorType: `${name} | mapId:${mapId} | isMtool:${isMtool}`,
                    stack: combined
                };

                try {
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', appScript);
                    xhr.setRequestHeader('Content-Type', 'application/json');
                    xhr.onerror = () => { };
                    xhr.send(JSON.stringify(payload));
                } catch { }
            };

            return `
                <h1 style="color: yellow;">${name}</h1>
                <h1 style="color: white; margin: 8px 0;">${getVersion()}</h1>
                <pre style="color: white;">${rawMessage}\n\n${rawStack}</pre>
            `;
        }
    });

    let gcWork = null;
    Object.assign(SceneManager, {
        // 避免報錯中止音頻播放
        onError(e) {
            console.trace(e.message);
            try {
                this.stop();
                Graphics.backupPrintError.call(Graphics, 'Error', e);
            } catch (e2) {
                console.trace(e2);
                Graphics.backupPrintError.call(Graphics, 'UnknownError', e2);
            }
        },
        catchException(e) {
            if (e instanceof Error) {
                Graphics.backupPrintError.call(Graphics, e.name, e);
                console.error(e.stack);
            } else {
                Graphics.backupPrintError.call(Graphics, 'UnknownError', e);
            }
            this.stop();
        },
        // 場景切換自動清理 GC
        changeScene() {
            if (this.isSceneChanging() && !this.isCurrentSceneBusy()) {
                if (this._scene) {
                    this._scene.terminate();
                    this._scene.detachReservation();
                    this._previousClass = this._scene.constructor;
                }

                const differentScene = this._scene && this._scene !== this._nextScene;
                this._scene = this._nextScene;
                if (this._scene) {
                    this._scene.attachReservation();
                    this._scene.create();
                    this._nextScene = null;
                    this._sceneStarted = false;
                    this.onSceneCreate();

                    if (differentScene) {
                        cancelIdleCallback(gcWork);
                        gcWork = requestIdleCallback(() => {
                            Graphics.callGC();
                        }, { timeout: 1e4 });
                    }
                }
                if (this._exiting) {
                    this.terminate();
                }
            }
        }
    });

    // ========== rpg_objects.js ==========

    Game_Battler.prototype.isStateAddable = function (stateId) {
        // ! this._result.isStateRemoved(stateId)  移除了当前回合不允许重复附加状态的限制
        return (this.isAlive() && $dataStates[stateId] &&
            !this.isStateResist(stateId) &&
            !this.isStateRestrict(stateId));
    };

    const old_initMembers = Game_Actor.prototype.initMembers;
    Object.assign(Game_Actor.prototype, {
        initMembers() {
            old_initMembers.call(this);
            this._weaponAmountLimit = 10;  // 武器携带上限
            this._armorAmountLimit = 20;  // 装备携带上限
            this._weaponAmountBonus = 0;  // 额外武器携带上限
            this._armorAmountBonus = 20;  // 额外装备携带上限
        },
        // 修改了脱下装备的逻辑
        discardEquip(item) {
            const slotId = this.equips().indexOf(item);
            if (slotId >= 0) {
                if (DataManager.isWeapon(item)) {
                    this.changeEquip(slotId, $dataWeapons[2]);
                } else if (DataManager.isArmor(item)) {
                    this.changeEquip(slotId, $dataArmors[2]);
                }
            }
        },
        // 原生的步数刷新状态回合
        onPlayerWalk() {
            this.clearResult();
            this.checkFloorEffect();
            if ($gamePlayer.isNormal()) {
                this.states().forEach(function (state) {
                    this.updateStateSteps(state);
                }, this);
                this.showAddedStates();
                this.showRemovedStates();
            }
        },
        // 步数刷新回合
        stepsForTurn() {
            return 1000;
        }
    });

    // 修改了game over判定
    Game_Unit.prototype.isAllDead = function () {
        return $gameActors.actor(1).isStateAffected(1);
    };

    Object.assign(Game_Map.prototype, {
        // 检查玩家有没有受困
        checkPlayerIsPassable() {
            const x = Math.floor($gamePlayer.centerRealX());
            const y = Math.floor($gamePlayer.centerRealY());

            return this.isPassable(x, y, 2) || // 下
                this.isPassable(x, y, 4) || // 左
                this.isPassable(x, y, 6) || // 右
                this.isPassable(x, y, 8);   // 上
        },
        //新增方法，主要用于重置演出事件
        resetMapeventSequence() {
            // 出于防范，重置玩家Z轴高度	
            $gamePlayer.mppHidPasZ = 0;
            // 出于防范，重置玩家举物状态
            $gamePlayer.drill_PT_clearLifting();
            // 出于防范，恢复玩家鼠标操作权限
            $gameSystem._drill_COI_map_mouse = true;
            // 出于防范，重置玩家行走图和移动权限
            $gamePlayer.drill_EASA_setEnabled(true);
            $gameSystem._drill_PAlM_enabled = true;

            // 非特定情况，淡出当前地图bgm
            if (!$gameSwitches.value(40)) {
                AudioManager.fadeOutBgm(2);
            }
            $gameSwitches.setValue(40, false);

            // 淡出可能存在的篝火音效
            if (AudioManager._allBgsBuffer && AudioManager._allBgsBuffer[12]) {
                AudioManager._allBgsBuffer[12].fadeOut(1);
            }
            // 清除旋风斩音效
            if (AudioManager._allBgsBuffer && AudioManager._allBgsBuffer[9]) {
                AudioManager.stopBgsByLine(9);
            }

            // 重置事件开关
            this._events.forEach(function (event) {
                if (event && event.event().note && (event.event().note.includes('<重置独立开关>') || event.event().note.includes('<resetSelfSwitch>'))) {
                    const eventId = event.eventId();
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'A'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'B'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'C'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'D'], false);
                }
            }, this);

            // 清除图片资源
            const maxPictures = 90;
            for (let pictureId = 3; pictureId <= maxPictures; pictureId++) {
                let picture = $gameScreen.picture(pictureId);
                if (picture) {
                    picture.drill_PCE_stopEffect();
                    $gameScreen.erasePicture(pictureId);
                }
            }

            // 清除图片点击判定
            $gameScreen._pictureCidArray = [];
            $gameScreen._pictureSidArray = [];
            $gameScreen._picturePidArray = [];
            $gameScreen._pictureTransparentArray = [];

            // 清除图片缓存
            // chahuiUtil.freePictureSubdirCache({ ignoreReservation:true, verbose:true });	
        }
    });

    Game_CharacterBase.prototype.animationWait = function () {
        // 新的速度范围是1到64，我们要找到一个新的基准值
        const baseSpeed = 64; // 最大速度
        const speed = this.realMoveSpeed();
        const maxWait = 24; // 原来的最慢速度对应的等待时间
        const minWait = 3; // 原来的最快速度对应的等待时间

        // 由于速度范围变化，我们需要重新计算等待时间的范围
        // 我们假设等待时间与速度成反比
        // 当速度最小时，等待时间最大；速度最大时，等待时间最小
        const waitTime = ((baseSpeed - speed) / (baseSpeed - 1)) * (maxWait - minWait) + minWait;

        return waitTime;
    };

    Object.assign(Game_Player.prototype, {
        // 修改了遇敌事件
        executeEncounter() {
            if (!$gameMap.isEventRunning() && this._encounterCount <= 0) {
                this.makeEncounterCount();
                const commonEventId = this.makeEncounterTroopId() + 299;
                if ($dataCommonEvents[commonEventId] && $dataCommonEvents[commonEventId].name) {
                    $gameTemp.reserveCommonEvent(commonEventId);
                    return false;
                }
            }
            return false;
        },
        // 增加了耐力消耗
        updateDashing() {
            if (this.isMoving()) {
                return;
            }
            if (!this._isPushing && this.canMove() && !this.isInVehicle() && !$gameMap.isDashDisabled()) {
                this._dashing = ConfigManager.alwaysDash || $gameTemp.isDestinationValid();
            } else {
                this._dashing = false;
            }
        }
    });

    Object.assign(Game_Interpreter.prototype, {
        videoFileExt() {
            return '.webm';
        },
        // 避免 class 內嚴格環境下, 解析失敗
        command355() {
            let script = this.currentCommand().parameters[0] + '\n';
            while (this.nextEventCode() === 655) {
                this._index++;
                script += this.currentCommand().parameters[0] + '\n';
            }
            eval(script);
            return true;
        }
    });

    // ========== rpg_scenes.js ==========

    const old_commandNewGame = Scene_Title.prototype.commandNewGame
    Scene_Title.prototype.commandNewGame = function () {
        const audio = {}
        audio.name = '風鈴の音'
        audio.volume = 90
        audio.pitch = 100
        AudioManager.playSe(audio);
        old_commandNewGame.call(this);
    };

    const superclass = Scene_Base.prototype;
    Object.assign(Scene_Map.prototype, {
        // 屏蔽了长按加速功能
        updateMainMultiply() {
            this.updateMain();
        },
        // 修改了地图界面中忙碌状态的判定
        isBusy() {
            if (this._itemWindow) {
                return this._waitCount > 0 || this._encounterEffectDuration > 0 ||
                    superclass.isBusy.call(this);
            } else {
                return ((this._messageWindow && this._messageWindow.isClosing()) ||
                    this._waitCount > 0 || this._encounterEffectDuration > 0 ||
                    superclass.isBusy.call(this));
            }
        },
        terminate() {
            superclass.terminate.call(this);
            if (!SceneManager.isNextScene(Scene_Battle)) {
                this._spriteset.update();
                this._mapNameWindow.hide();
                SceneManager.snapForBackground();
            } else {
                ImageManager.clearRequest();
            }

            if (SceneManager.isNextScene(Scene_Map)) {
                // 新增方法，主要用于重置演出事件
                $gameMap.resetMapeventSequence();
                ImageManager.clearRequest();
            }

            $gameScreen.clearZoom();

            this.removeChild(this._fadeSprite);
            this.removeChild(this._mapNameWindow);
            this.removeChild(this._windowLayer);
            this.removeChild(this._spriteset);
        },
        // 取消鼠标右键打开菜单的功能
        updateCallMenu() {
            if (this.isMenuEnabled()) {
                if (this.menuCalling && !$gamePlayer.isMoving()) {
                    this.callMenu();
                }
            } else {
                this.menuCalling = false;
            }
        }
    });

    // 追加了选项窗口透明度为0
    Scene_Options.prototype.createOptionsWindow = function () {
        this._optionsWindow = new Window_Options();
        this._optionsWindow.setHandler('cancel', this.popScene.bind(this));
        this._optionsWindow.opacity = 0;
        this.addWindow(this._optionsWindow);
    };

    // ========== rpg_windows.js ==========

    // 图标尺寸
    Object.assign(Window_Base, {
        _iconWidth: 64,
        _iconHeight: 64
    });

    Object.assign(Window_Base.prototype, {
        // 竖排版函数
        drawVerticalText(text, x, y) {
            let lineHeight = this.contents.fontSize;
            let characters = text.split('');

            for (let i = 0; i < characters.length; i++) {
                let character = characters[i];
                this.drawText(character, x, y + i * lineHeight);
            }
        },
        // 转义符绘制图标
        processDrawIcon(iconIndex, textState) {
            this.drawIcon(iconIndex, textState.x + 2, textState.y - 2);
            textState.x += Window_Base._iconWidth + 4;
        },
        // 绘制图标的函数
        drawIcon(iconIndex, x, y) {
            const bitmap = ImageManager.loadSystem('IconSet_large');
            const pw = Window_Base._iconWidth;
            const ph = Window_Base._iconHeight;
            const sx = iconIndex % 16 * pw;
            const sy = Math.floor(iconIndex / 16) * ph;
            this.contents.blt(bitmap, sx, sy, pw, ph, x, y);
        },
    });

    Object.assign(Window_Message.prototype, {
        // 取消了快进会导致等待帧转义字符失效的效果
        updateMessage() {
            if (this._textState) {
                while (!this.isEndOfText(this._textState)) {
                    if (this.needsNewPage(this._textState)) {
                        this.newPage(this._textState);
                    }
                    this.updateShowFast();
                    this.processCharacter(this._textState);
                    // 先看等待/暂停
                    if (this.pause || this._waitCount > 0) {
                        break;
                    }
                    // 再看是否要继续快进
                    if (!this._showFast && !this._lineShowFast) {
                        break;
                    }
                }
                if (this.isEndOfText(this._textState)) {
                    this.onEndOfText();
                }
                return true;
            } else {
                return false;
            }
        },
        // 鼠标长按状态下加速等待帧计时
        updateWait() {
            if (this._waitCount > 0) {
                // 追加单击时无视等待指令
                if (TouchInput.isTriggered()) this._waitCount = 5;
                this._waitCount -= TouchInput.isPressed() ? 2 : 1;
                return true;
            } else {
                return false;
            }
        },
    });

    // 文本描述栏默认宽度和行数
    Window_Help.prototype.initialize = function (numLines) {
        const width = Graphics.boxWidth;
        const height = this.fittingHeight(numLines || 4);
        Window_Base.prototype.initialize.call(this, 0, 0, width, height);
        this._text = '';
    };

    // 读取玩家选中道具的ID，控制台用
    Window_ItemList.prototype.printItemId = function () {
        const item = this.item();
        if (item) {
            console.log('Selected item ID:', item.id);
        }
    };

    // 阻止修改技能名称、图标的透明度修改
    Window_SkillList.prototype.drawItem = function (index) {
        const skill = this._data[index];
        if (skill) {
            const costWidth = this.costWidth();
            const rect = this.itemRect(index);
            rect.width -= this.textPadding();
            this.drawItemName(skill, rect.x, rect.y, rect.width - costWidth);
            this.drawSkillCost(skill, rect.x, rect.y, rect.width);
            this.changePaintOpacity(1);
        }
    };

    Object.assign(Window_Options.prototype, {
        // 始终冲刺、记住指令功能
        addGeneralOptions() { },
        // BGM、BGS、ME、SE控制
        addVolumeOptions() {
            this.addCommand(TextManager.bgmVolume, 'bgmVolume');
            this.addCommand(TextManager.bgsVolume, 'bgsVolume');
            this.addCommand(TextManager.seVolume, 'seVolume');
        }
    });

    Window_ChoiceList.prototype.select = function (index) {
        Window_Command.prototype.select.call(this, index);
        this._eventRan = false;
    };

})();

(() => {
    const add = (() => {
        const addRecord = new Map();
        function addHead(type, rule, id = crypto.randomUUID(), repeatAdd = true) {
            let element = addRecord.get(id);

            if (!repeatAdd && element) return;
            if (!element) {
                element = document.createElement(type);
                element.id = id;
                document.head.appendChild(element);
            };

            element.textContent += rule;
            addRecord.set(id, element);
        };

        return {
            style: (rule, id, repeatAdd) => addHead("style", rule, id, repeatAdd),
            script: (rule, id, repeatAdd) => addHead("script", rule, id, repeatAdd),
        }
    })();

    const dialogStyle = `
        .custom-dialog-overlay {
            position: fixed;
            inset: 0;
            background: rgba(20, 15, 20, 0.75);
            display: grid;
            place-items: center;
            z-index: 10000;
            backdrop-filter: blur(3px);
            padding: clamp(12px, 4vw, 60px);
            box-sizing: border-box;
        }

        /* 動畫效果類 */
        .custom-dialog-overlay.animated-fade {
            animation: fadeIn 0.4s ease-out;
        }

        .custom-dialog-overlay.animated-fade.closing {
            animation: fadeOut 0.35s ease-out;
        }

        .custom-dialog-overlay.no-animation {
            opacity: 1;
        }

        .custom-dialog {
            background: linear-gradient(135deg, 
                rgba(0,0,0,0)   0%,
                rgba(0,0,0,.28) 22%,
                rgba(0,0,0,.48) 50%,
                rgba(0,0,0,.28) 78%);
            border-radius: clamp(12px, 3vw, 18px);
            padding: 3px;
            width: clamp(280px, 90vw, 420px);
            max-width: 100%;
            max-height: clamp(400px, 85vh, 90vh);
            box-shadow: 
                0 0 25px rgba(50, 50, 50, 0.2),
                0 0 50px rgba(75, 75, 75, 0.15),
                0 12px 35px rgba(0, 0, 0, 0.4);
            position: relative;
            overflow: hidden;
            box-sizing: border-box;
        }

        /* 邊框光暈動畫 */
        .custom-dialog::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: linear-gradient(
                45deg,
                transparent 30%,
                rgba(15, 15, 15, 0.3) 50%,
                transparent 70%
            );
            animation: borderShine 4s linear infinite;
            pointer-events: none;
        }

        @keyframes borderShine {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        /* 淡入效果 */
        .custom-dialog.animated-fade {
            animation: dialogFadeIn 0.4s ease-out;
        }

        .custom-dialog.animated-fade.closing {
            animation: dialogFadeOut 0.35s ease-out;
        }

        /* 從上滑入 */
        .custom-dialog.animated-slide-top {
            animation: slideFromTop 0.45s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        .custom-dialog.animated-slide-top.closing {
            animation: slideToTop 0.35s cubic-bezier(0.55, 0.085, 0.68, 0.53);
        }

        /* 從下滑入 */
        .custom-dialog.animated-slide-bottom {
            animation: slideFromBottom 0.45s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        .custom-dialog.animated-slide-bottom.closing {
            animation: slideToBottom 0.35s cubic-bezier(0.55, 0.085, 0.68, 0.53);
        }

        /* 從左滑入 */
        .custom-dialog.animated-slide-left {
            animation: slideFromLeft 0.45s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        .custom-dialog.animated-slide-left.closing {
            animation: slideToLeft 0.35s cubic-bezier(0.55, 0.085, 0.68, 0.53);
        }

        /* 從右滑入 */
        .custom-dialog.animated-slide-right {
            animation: slideFromRight 0.45s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        .custom-dialog.animated-slide-right.closing {
            animation: slideToRight 0.35s cubic-bezier(0.55, 0.085, 0.68, 0.53);
        }

        /* 縮放效果 */
        .custom-dialog.animated-scale {
            animation: scaleIn 0.45s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }

        .custom-dialog.animated-scale.closing {
            animation: scaleOut 0.35s cubic-bezier(0.6, -0.28, 0.735, 0.045);
        }

        /* 無動畫 */
        .custom-dialog.no-animation {
            opacity: 1;
            transform: none;
        }

        .custom-dialog-content {
            background: linear-gradient(135deg, 
                rgba(255, 255, 255, 0.96) 0%,
                rgba(255, 255, 255, 0.98) 100%);
            backdrop-filter: blur(10px);
            border-radius: clamp(10px, 2.5vw, 15px);
            padding: clamp(16px, 4vw, 24px);
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            max-height: calc(85vh - 6px);
            box-sizing: border-box;
        }

        .custom-dialog-content::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 2px;
            background: linear-gradient(90deg, 
                transparent 0%, 
			    rgba(255,255,255,0)    0%,
			    rgba(255,255,255,0.28) 22%,
			    rgba(255,255,255,0.50) 50%,
			    rgba(255,255,255,0.28) 78%,
                transparent 100%);
            animation: shimmer 3s infinite;
        }

        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* 標題占位符（無標題時使用） */
        .custom-dialog-title-spacer {
            height: clamp(8px, 2vh, 16px);
            flex-shrink: 0;
        }

        .custom-dialog-title {
            font-size: clamp(16px, 3.5vw, 19px);
            font-weight: 800;
            background: linear-gradient(90deg, 
                #bfbfbf 0%, 
                #9e9e9e 35%, 
                #494949 65%, 
                #000000 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            margin-bottom: clamp(12px, 3vw, 16px);
            text-align: center;
            font-family: 'Segoe UI', 'Helvetica Neue', 'Arial', sans-serif;
            letter-spacing: clamp(0.5px, 0.15vw, 1px);
            filter: drop-shadow(0 0 6px rgba(15, 15, 15, 0.4));
            flex-shrink: 0;
        }

        .custom-dialog-message-container {
            flex: 1;
            overflow-y: auto;
            overflow-x: hidden;
            margin-bottom: clamp(12px, 3vw, 18px);
            min-height: clamp(40px, 10vh, 60px);
            max-height: clamp(200px, 50vh, 400px);
            padding: 2px clamp(4px, 1.5vw, 8px);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
        }

        /* 自定義滾動條 */
        .custom-dialog-message-container::-webkit-scrollbar {
            width: clamp(6px, 1.5vw, 8px);
        }

        .custom-dialog-message-container::-webkit-scrollbar-track {
            background: rgba(40, 40, 40, 0.05);
            border-radius: 4px;
        }

        .custom-dialog-message-container::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, 
                rgba(0, 0, 0, 0.4) 0%, 
                rgba(0, 0, 0, 0.6) 100%);
            border-radius: 4px;
            border: 2px solid transparent;
            background-clip: padding-box;
        }

        .custom-dialog-message-container::-webkit-scrollbar-thumb:hover {
            background: linear-gradient(180deg, 
                rgba(30, 30, 30, 0.7) 0%, 
                rgba(0, 0, 0, 0.9) 100%);
            background-clip: padding-box;
        }

        .custom-dialog-message {
            font-size: clamp(14px, 3.2vw, 18px);
            color: rgba(0, 0, 0, 0.98);
            font-weight: 500;
            line-height: 1.75;
            text-align: center;
            word-wrap: break-word;
            word-break: break-word;
            font-family: 'Segoe UI', 'Helvetica Neue', 'Arial', sans-serif;
            letter-spacing: clamp(0.2px, 0.05vw, 0.3px);
            text-shadow:
                0 1px 2px rgba(0, 0, 0, 0.3),
                0 0 8px rgba(255, 200, 225, 0.2);
        }

        .custom-dialog-input-container {
            flex-shrink: 0;
            margin-bottom: clamp(12px, 3vw, 18px);
        }

        .custom-dialog-input {
            width: 100%;
            padding: clamp(10px, 2vw, 12px) clamp(12px, 3vw, 16px);
            border: 2px solid rgba(255, 200, 225, 0.25);
            border-radius: clamp(8px, 2vw, 10px);
            font-size: clamp(14px, 3vw, 16px);
            background: rgba(25, 25, 25, 0.6);
            color: rgba(255, 255, 255, 0.95);
            font-family: 'Segoe UI', 'Helvetica Neue', 'Arial', sans-serif;
            transition: all 0.3s ease;
            letter-spacing: clamp(0.2px, 0.05vw, 0.3px);
            box-sizing: border-box;
        }

        .custom-dialog-input::placeholder {
            color: rgba(225, 225, 225, 0.65);
        }

        .custom-dialog-input:focus {
            outline: none;
            border-color: rgba(45, 45, 45, 0.6);
            background: rgba(25, 15, 25, 0.8);
            box-shadow: 
                0 0 12px rgba(255, 200, 225, 0.25),
                inset 0 0 8px rgba(255, 200, 225, 0.08);
        }

        .custom-dialog-buttons {
            display: flex;
            gap: clamp(6px, 1.5vw, 10px);
            justify-content: flex-end;
            flex-shrink: 0;
            flex-wrap: wrap;
        }

        .custom-dialog-button {
            padding: clamp(8px, 2vw, 10px) clamp(16px, 4vw, 24px);
            border: none;
            border-radius: clamp(6px, 1.5vw, 8px);
            font-size: clamp(13px, 2.8vw, 15px);
            font-weight: 600;
            cursor: pointer;
            transition: all 0.25s ease;
            min-width: clamp(60px, 15vw, 80px);
            font-family: 'Segoe UI', 'Helvetica Neue', 'Arial', sans-serif;
            letter-spacing: clamp(0.3px, 0.08vw, 0.5px);
            position: relative;
            overflow: hidden;
            outline: none;
            box-sizing: border-box;
        }

        .custom-dialog-button::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 0;
            height: 0;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.2);
            transform: translate(-50%, -50%);
            transition: width 0.4s, height 0.4s;
        }

        .custom-dialog-button:active::before {
            width: 300px;
            height: 300px;
        }

        .custom-dialog-button:focus {
            outline: none;
        }

        .custom-dialog-button-primary {
            background: linear-gradient(135deg, 
                rgba(85, 85, 85, 0.95) 0%, 
                rgba(0, 0, 0, 0.95) 100%);
            color: rgba(255, 255, 255, 0.98);
            box-shadow: 
                0 4px 12px rgba(250, 170, 200, 0.3),
                0 0 20px rgba(255, 200, 225, 0.2);
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
        }

        .custom-dialog-button-primary:hover {
            background: linear-gradient(135deg, 
                rgba(45, 45, 45, 0.98) 0%, 
                rgba(0, 0, 0, 0.98) 100%);
            transform: translateY(-2px);
            box-shadow: 
                0 6px 16px rgba(60, 60, 60, 0.4),
                0 0 30px rgba(0, 0, 0, 0.3);
        }

        .custom-dialog-button-primary:active {
            transform: translateY(0);
            box-shadow: 
                0 2px 6px rgba(0, 0, 0, 0.4);
        }

        .custom-dialog-button-secondary {
            background: linear-gradient(135deg,
                rgba(255, 255, 255, 0.85) 0%,
                rgba(225, 225, 225, 0.85) 100%);
            color: rgba(15, 15, 15, 0.9);
			border: 1px solid rgba(0,0,0,.66);
            box-shadow: 0 2px 8px rgba(0,0,0,.16);
            text-shadow: 0 1px 2px rgba(0, 0, 0, 0.3);
        }

        .custom-dialog-button-secondary:hover {
            background: linear-gradient(135deg,
                rgba(250, 250, 250, 0.9) 0%,
                rgba(240, 240, 240, 0.9) 100%);
            color: rgba(0, 0, 0, 0.9);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.4);
        }

        .custom-dialog-button-secondary:active {
            transform: translateY(0);
            box-shadow: 0 1px 4px rgba(0, 0, 0, 0.3);
        }

        /* 位置類 - 使用 CSS Grid 布局 */
        .position-top { 
            place-items: start center;
        }
        
        .position-center { 
            place-items: center;
        }
        
        .position-bottom { 
            place-items: end center;
        }
        
        .position-left { 
            place-items: center start;
        }
        
        .position-right { 
            place-items: center end;
        }

        /* 小屏幕優化 */
        @media (max-width: 640px) {
            .custom-dialog-overlay {
                padding: 16px;
            }

            .custom-dialog {
                width: 100%;
                max-width: calc(100vw - 32px);
            }

            .custom-dialog-buttons {
                flex-direction: column-reverse;
                gap: 8px;
            }

            .custom-dialog-button {
                width: 100%;
                min-width: unset;
            }

            .custom-dialog-message-container {
                max-height: 60vh;
            }
        }

        /* 超小屏幕 */
        @media (max-width: 380px) {
            .custom-dialog-overlay {
                padding: 8px;
            }

            .custom-dialog {
                border-radius: 12px;
            }

            .custom-dialog-content {
                padding: 12px;
            }

            .custom-dialog-title {
                font-size: 15px;
                margin-bottom: 10px;
            }

            .custom-dialog-message {
                font-size: 13px;
            }
        }

        /* 動畫定義 */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        @keyframes dialogFadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes dialogFadeOut {
            from { opacity: 1; }
            to { opacity: 0; }
        }

        @keyframes slideFromTop {
            from {
                transform: translateY(clamp(-40px, -10vw, -60px));
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideToTop {
            from {
                transform: translateY(0);
                opacity: 1;
            }
            to {
                transform: translateY(clamp(-40px, -10vw, -60px));
                opacity: 0;
            }
        }

        @keyframes slideFromBottom {
            from {
                transform: translateY(clamp(40px, 10vw, 60px));
                opacity: 0;
            }
            to {
                transform: translateY(0);
                opacity: 1;
            }
        }

        @keyframes slideToBottom {
            from {
                transform: translateY(0);
                opacity: 1;
            }
            to {
                transform: translateY(clamp(40px, 10vw, 60px));
                opacity: 0;
            }
        }

        @keyframes slideFromLeft {
            from {
                transform: translateX(clamp(-40px, -10vw, -60px));
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideToLeft {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(clamp(-40px, -10vw, -60px));
                opacity: 0;
            }
        }

        @keyframes slideFromRight {
            from {
                transform: translateX(clamp(40px, 10vw, 60px));
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @keyframes slideToRight {
            from {
                transform: translateX(0);
                opacity: 1;
            }
            to {
                transform: translateX(clamp(40px, 10vw, 60px));
                opacity: 0;
            }
        }

        @keyframes scaleIn {
            from {
                transform: scale(0.7);
                opacity: 0;
            }
            to {
                transform: scale(1);
                opacity: 1;
            }
        }

        @keyframes scaleOut {
            from {
                transform: scale(1);
                opacity: 1;
            }
            to {
                transform: scale(0.7);
                opacity: 0;
            }
        }
    `;

    class DialogManager {
        constructor() {
            this.dialogQueue = [];
            this.currentDialog = null;
            this.isProcessing = false;
            this.transitionDelay = 100; // 多對話框間的過渡延遲

            this.positionMap = {
                top: 'position-top',
                center: 'position-center',
                bottom: 'position-bottom',
                left: 'position-left',
                right: 'position-right'
            };

            this.animationMap = {
                fade: 'animated-fade',
                top: 'animated-slide-top',
                bottom: 'animated-slide-bottom',
                left: 'animated-slide-left',
                right: 'animated-slide-right',
                scale: 'animated-scale'
            };

            this.durationMap = {
                fade: 400,
                top: 450,
                bottom: 450,
                left: 450,
                right: 450,
                scale: 450
            };

            this.fragment = document.createDocumentFragment();
            add.style(dialogStyle, "dialog-style", false);
        };

        stopScene() {
            if (!SceneManager?._stopped) SceneManager.stop();
        };

        resumeScene() {
            if (SceneManager?._stopped) SceneManager.resume();
        };

        getPositionClass(position) {
            return this.positionMap[position] || 'position-center';
        };

        getAnimationClass(animation) {
            if (!animation || animation === 'none') return 'no-animation';
            if (animation === true) return 'animated-fade';
            return this.animationMap[animation] || 'animated-fade';
        };

        getAnimationDuration(animation) {
            if (!animation || animation === 'none') return 0;
            if (animation === true) return 400;
            return this.durationMap[animation] || 400;
        };

        enqueue(options) {
            return new Promise(resolve => {
                this.dialogQueue.push({ options, resolve });
                if (!this.isProcessing) this.processQueue();
            })
        };

        async processQueue() {
            if (this.dialogQueue.length === 0) {
                this.isProcessing = false;
                this.resumeScene();
                return;
            }

            this.isProcessing = true;
            const { options, resolve } = this.dialogQueue.shift();
            const hasNextDialog = this.dialogQueue.length > 0;

            if (!this.currentDialog) this.stopScene();

            if (this.currentDialog) {
                await this.closeCurrentDialog(this.currentDialog.animation, hasNextDialog);

                if (hasNextDialog) {
                    await new Promise(resolve => setTimeout(resolve, this.transitionDelay));
                }
            }

            // 創建新對話框
            const result = await this.createDialog(options);
            resolve(result);

            this.processQueue();
        };

        closeCurrentDialog(animation, hasNextDialog = false) {
            return new Promise(resolve => {
                if (!this.currentDialog) return resolve();

                const { overlay, dialog } = this.currentDialog;
                const duration = this.getAnimationDuration(animation);

                const remove = () => {
                    if (hasNextDialog) {
                        overlay.style.transition = 'opacity 0.15s ease-out';
                        overlay.style.opacity = '0';
                        setTimeout(() => {
                            overlay.remove();
                            this.currentDialog = null;
                            resolve();
                        }, 150);
                    } else {
                        overlay.remove();
                        this.currentDialog = null;
                        resolve();
                    }
                };

                if (duration > 0) {
                    overlay.classList.add('closing');
                    dialog.classList.add('closing');
                    setTimeout(remove, duration * 0.9);
                } else {
                    remove();
                }
            })
        };

        createDialog(rawOptions) {
            return new Promise(resolve => {
                const {
                    type = 'alert',
                    message = '',
                    title = '',
                    confirmText = 'OK',
                    cancelText = 'Cancel',
                    defaultValue = '',
                    placeholder = 'Enter text...',
                    position = 'center',
                    autoClose = false,
                    duration = 3,
                    animation = 'fade'
                } = rawOptions;

                const overlayAnimationClass = !animation || animation === 'none'
                    ? 'no-animation'
                    : 'animated-fade';

                const dialogAnimationClass = this.getAnimationClass(animation);
                const hasQueue = this.dialogQueue.length > 0;

                const overlay = document.createElement('div');
                overlay.className = `custom-dialog-overlay ${overlayAnimationClass} ${this.getPositionClass(position)}`;

                // 如果有隊列，初始設為半透明，避免閃爍
                if (hasQueue) overlay.style.opacity = '0';

                const dialog = document.createElement('div');
                dialog.className = `custom-dialog ${dialogAnimationClass}`;

                const content = document.createElement('div');
                content.className = 'custom-dialog-content';

                if (title) {
                    const titleEl = document.createElement('div');
                    titleEl.className = 'custom-dialog-title';
                    titleEl.textContent = title;
                    content.appendChild(titleEl);
                } else {
                    const spacer = document.createElement('div');
                    spacer.className = 'custom-dialog-title-spacer';
                    content.appendChild(spacer);
                };

                const msgBox = document.createElement('div');
                msgBox.className = 'custom-dialog-message-container';

                const msg = document.createElement('div');
                msg.className = 'custom-dialog-message';
                msg.innerHTML = message.replace(/\n/g, '<br>');

                msgBox.appendChild(msg);
                content.appendChild(msgBox);

                let inputElement = null;
                if (type === 'prompt') {
                    const inputWrap = document.createElement('div');
                    inputWrap.className = 'custom-dialog-input-container';

                    inputElement = document.createElement('input');
                    inputElement.className = 'custom-dialog-input';
                    inputElement.type = 'text';
                    inputElement.value = defaultValue;
                    inputElement.placeholder = placeholder;

                    inputWrap.appendChild(inputElement);
                    content.appendChild(inputWrap);

                    inputElement.addEventListener('keydown', e => {
                        if (e.key === 'Enter') {
                            e.preventDefault();
                            handleConfirm();
                        }
                    })
                };

                const btnBox = document.createElement('div');
                btnBox.className = 'custom-dialog-buttons';

                const handleConfirm = () => {
                    const result = type === 'prompt'
                        ? inputElement?.value ?? ''
                        : true;

                    const hasNextInQueue = this.dialogQueue.length > 0;

                    this.closeDialog(overlay, dialog, () => {
                        if (!hasNextInQueue) this.resumeScene();
                        resolve(result);
                    }, animation, hasNextInQueue);
                };

                const handleCancel = () => {
                    const result = type === 'prompt'
                        ? null
                        : false;

                    const hasNextInQueue = this.dialogQueue.length > 0;

                    this.closeDialog(overlay, dialog, () => {
                        if (!hasNextInQueue) this.resumeScene();
                        resolve(result);
                    }, animation, hasNextInQueue);
                };

                if (type === 'confirm' || type === 'prompt') {
                    const cancelBtn = document.createElement('button');
                    cancelBtn.className = 'custom-dialog-button custom-dialog-button-secondary';
                    cancelBtn.textContent = cancelText;
                    cancelBtn.addEventListener("pointerup", handleCancel);
                    btnBox.appendChild(cancelBtn);
                };

                const confirmBtn = document.createElement('button');
                confirmBtn.className = 'custom-dialog-button custom-dialog-button-primary';
                confirmBtn.textContent = confirmText;
                confirmBtn.addEventListener("pointerup", handleConfirm);
                btnBox.appendChild(confirmBtn);

                content.appendChild(btnBox);
                dialog.appendChild(content);
                overlay.appendChild(dialog);

                this.fragment.appendChild(overlay);
                document.body.appendChild(this.fragment);

                this.currentDialog = { overlay, dialog, animation };

                // 如果有隊列，延遲後淡入
                if (hasQueue) {
                    requestAnimationFrame(() => {
                        overlay.style.transition = 'opacity 0.2s ease-in';
                        overlay.style.opacity = '1';
                    })
                };

                // 延遲聚焦，確保動畫流暢
                setTimeout(() => {
                    if (inputElement) {
                        inputElement.focus();
                    } else {
                        confirmBtn.focus();
                    }
                }, hasQueue ? 150 : 50);

                if (autoClose && duration > 0) {
                    setTimeout(() => {
                        if (this.currentDialog?.overlay === overlay) handleConfirm();
                    }, duration * 1000);
                };
            })
        };

        closeDialog(overlay, dialog, callback, animation, hasNextDialog = false) {
            const duration = this.getAnimationDuration(animation);

            const finish = () => {
                if (hasNextDialog) {
                    overlay.style.transition = 'opacity 0.15s ease-out';
                    overlay.style.opacity = '0';
                    setTimeout(() => {
                        overlay.remove();
                        if (this.currentDialog?.overlay === overlay) {
                            this.currentDialog = null;
                        }
                        callback?.();
                    }, 150);
                } else {
                    overlay.remove();
                    if (this.currentDialog?.overlay === overlay) {
                        this.currentDialog = null;
                    }
                    callback?.();
                }
            };

            if (duration > 0 && !hasNextDialog) {
                overlay.classList.add('closing');
                dialog.classList.add('closing');
                setTimeout(finish, duration * 0.9);
            } else finish();
        }
    };

    const dialogManager = new DialogManager();

    Object.assign(window, {
        alert: (message, options = {}) => dialogManager.enqueue({
            type: 'alert',
            message: String(message ?? ''),
            ...options
        }),
        confirm: (message, options = {}) => dialogManager.enqueue({
            type: 'confirm',
            message: String(message ?? ''),
            ...options
        }),
        prompt: (message, defaultValue = '', options = {}) => dialogManager.enqueue({
            type: 'prompt',
            message: String(message ?? ''),
            defaultValue: String(defaultValue ?? ''),
            ...options
        })
    });

})();