(() => {
    // 手机版补丁
    if (!Utils.isMobileDevice()) return;

    // ========== rpg_core.js ==========

    // 确保能够读取自动更新的json、png、ogg文件
    WebAudio.prototype._load = function (url) {
        if (!WebAudio._context) return;
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var firstUrl = Decrypter.hasEncryptedAudio
            ? Decrypter.extToEncryptExt(url)
            : url;
        var dataFull = dataBase + firstUrl;
        var originalRequest = function () {
            var xhr = new XMLHttpRequest();
            xhr.open("GET", firstUrl);
            xhr.responseType = "arraybuffer";
            xhr.onload = function () {
                if (xhr.status < 400) {
                    this._onXhrLoad(xhr);
                }
            }.bind(this);
            xhr.onerror = this._loader || function () { this._hasError = true; }.bind(this);
            xhr.send();
        }.bind(this);

        window.resolveLocalFileSystemURL(
            dataFull,
            function (entry) {
                entry.file(function (file) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        //console.log("[WebAudio] Loaded from dataDirectory:", dataFull);
                        var fakeXhr = { response: reader.result };
                        this._onXhrLoad(fakeXhr);
                    }.bind(this);
                    reader.onerror = originalRequest;
                    reader.readAsArrayBuffer(file);
                }.bind(this), originalRequest);
            }.bind(this),
            originalRequest
        );
    };

    Bitmap.prototype._requestImage = function (url) {
        if (Bitmap._reuseImages.length !== 0) {
            this._image = Bitmap._reuseImages.pop();
        } else { this._image = new Image(); }
        if (this._decodeAfterRequest && !this._loader) {
            this._loader = ResourceHandler.createLoader(
                url,
                this._requestImage.bind(this, url),
                this._onError.bind(this)
            );
        }
        this._url = url;
        this._loadingState = 'requesting';

        // ===== check for image encryption =====
        if (!Decrypter.checkImgIgnore(url) && Decrypter.hasEncryptedImages) {
            this._loadingState = 'decrypting';
            Decrypter.decryptImg(url, this);
            return;
        }

        // ===== use of unencrypted images =====
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var dataFull = dataBase + url;
        var originalLoad = function () {
            this._image.src = url;
            this._image.addEventListener(
                'load',
                this._loadListener = Bitmap.prototype._onLoad.bind(this)
            );
            this._image.addEventListener(
                'error',
                this._errorListener = this._loader || Bitmap.prototype._onError.bind(this)
            );
        }.bind(this);
        var tryLocal = function (path, onSuccess, onFail) {
            window.resolveLocalFileSystemURL(
                path,
                function (entry) {
                    entry.file(function (file) {
                        var reader = new FileReader();
                        reader.onload = function () {
                            //console.log('[Bitmap] Loaded from dataDirectory:', path);
                            var blob = new Blob([reader.result]);
                            this._image.src = URL.createObjectURL(blob);
                            this._image.addEventListener(
                                'load',
                                this._loadListener = Bitmap.prototype._onLoad.bind(this)
                            );
                            this._image.addEventListener(
                                'error',
                                this._errorListener = this._loader || Bitmap.prototype._onError.bind(this)
                            );
                        }.bind(this);
                        reader.onerror = onFail;
                        reader.readAsArrayBuffer(file);
                    }.bind(this), onFail);
                }.bind(this),
                onFail
            );
        }.bind(this);
        tryLocal(
            dataFull,
            function () {
            },
            originalLoad
        );
    };

    Decrypter.decryptImg = function (url, bitmap) {
        var relativeUrl = this.extToEncryptExt(url);
        var dataBase = window.cdvUrl || "";
        if (dataBase && !dataBase.endsWith("/")) dataBase += "/";
        var dataFull = dataBase + relativeUrl;
        function originalRequest() {
            var req = new XMLHttpRequest();
            req.open("GET", relativeUrl);
            req.responseType = "arraybuffer";
            req.send();
            req.onload = function () {
                if (this.status < Decrypter._xhrOk) {
                    var decrypted = Decrypter.decryptArrayBuffer(req.response);
                    bitmap._image.src = Decrypter.createBlobUrl(decrypted);
                    bitmap._image.addEventListener(
                        "load",
                        bitmap._loadListener = Bitmap.prototype._onLoad.bind(bitmap)
                    );
                    bitmap._image.addEventListener(
                        "error",
                        bitmap._errorListener = bitmap._loader || Bitmap.prototype._onError.bind(bitmap)
                    );
                } else {
                    if (bitmap._loader) bitmap._loader();
                    else bitmap._onError();
                }
            };
            req.onerror = function () {
                if (bitmap._loader) bitmap._loader();
                else bitmap._onError();
            };
        }
        window.resolveLocalFileSystemURL(
            dataFull,
            function (entry) {
                entry.file(function (file) {
                    var reader = new FileReader();
                    reader.onload = function () {
                        //console.log("[Decrypter] Loaded from dataDirectory:", dataFull);
                        var decrypted = Decrypter.decryptArrayBuffer(reader.result);
                        bitmap._image.src = Decrypter.createBlobUrl(decrypted);
                        bitmap._image.addEventListener(
                            "load",
                            bitmap._loadListener = Bitmap.prototype._onLoad.bind(bitmap)
                        );
                        bitmap._image.addEventListener(
                            "error",
                            bitmap._errorListener = bitmap._loader || Bitmap.prototype._onError.bind(bitmap)
                        );
                    };
                    reader.onerror = function () {
                        originalRequest();
                    };
                    reader.readAsArrayBuffer(file);
                }, function () {
                    originalRequest();
                });
            },
            function () {
                originalRequest();
            }
        );
    };

    // ========== rpg_managers.js ==========

    // 在外部读写游戏文件
    Object.assign(DataManager, {
        loadDataFile(name, src) {
            var xhr = new XMLHttpRequest();
            var url = window.cdvUrl + 'data/' + src;
            xhr.open('GET', url);
            xhr.overrideMimeType('application/json');
            xhr.onload = function () {
                if (xhr.status < 400) {
                    window[name] = JSON.parse(xhr.responseText);
                    DataManager.onLoad(window[name]);
                }
            };
            xhr.onerror = this._mapLoader || function () {
                DataManager._errorUrl = DataManager._errorUrl || url;
            };
            window[name] = null;
            xhr.send();
        },
        loadMapData(mapId) {
            if (mapId > 0) {
                var filename = 'Map%1.json'.format(mapId.padZero(3));
                this._mapLoader = ResourceHandler.createLoader(window.cdvUrl + 'data/' + filename, this.loadDataFile.bind(this, '$dataMap', filename));
                this.loadDataFile('$dataMap', filename);
            } else {
                this.makeEmptyMap();
            }
        }
    });

    Object.assign(StorageManager, {
        loadFromWebStorage(savefileId) {
            var data = null;
            var filePath = this.localFilePath(savefileId);
            data = AndroidSave.loadSave(filePath);
            return data;
        },
        saveToWebStorage(savefileId, json) {
            var filePath = this.localFilePath(savefileId);
            AndroidSave.saveGame(filePath, json);
        },
        removeWebStorage(savefileId) {
            var filePath = this.localFilePath(savefileId);
            AndroidSave.removeSave(filePath);
        },
        webStorageExists(savefileId) {
            var fileName = this.localFilePath(savefileId);
            return AndroidSave.loadSaveExists(fileName);
        }
    });

    PluginManager.loadScript = function (name) {
        var url = window.cdvUrl + this._path + name;
        var script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = url;
        script.async = false;
        script.onerror = this.onError.bind(this);
        script._url = url;
        document.body.appendChild(script);
    };
})();

(() => {
    // ========== rpg_managers.js ==========

    let gcWork = null;
    let getVersion = () => {
        let ver = "";
        // 1) 从 System 标题里解析 “verX.X.X”
        if ($dataSystem.gameTitle) {
            const m = $dataSystem.gameTitle.match(/ver\s*([A-Za-z0-9._-]+)/i);
            if (m) ver = m[1];
        };

        // 2) 兜底：从 document.title 里再试一次
        if (!ver && document.title) {
            const m2 = document.title.match(/ver\s*([A-Za-z0-9._-]+)/i);
            if (m2) ver = m2[1];
        };

        // 设备标记
        const suffix = (window.Utils && Utils.isMobileDevice()) ? " (Android)" : "";
        const result = `Current Version: ${ver || ""}${suffix}`;

        getVersion = () => result;
        return result;
    };

    Object.assign(Graphics, {
        backupPrintError: Graphics.printError, // 避免被覆蓋
        _makeErrorHtml(name = "UnknownError", error = {}) {
            return `
                <h1 style="color: yellow;">${name}</h1>
                <h1 style="color: white; margin: 8px 0;">${getVersion()}</h1>
                <pre style="color: white;">${error.message || ""}\n\n${error.stack || ""}</pre>
            `;
        }
    });

    Object.assign(SceneManager, {
        // 避免報錯中止音頻播放
        onError(e) {
            console.trace(e.message);
            try {
                this.stop();
                Graphics.backupPrintError.call(Graphics, 'Error', e);
            } catch (e2) {
                console.trace(e2);
                Graphics.backupPrintError.call(Graphics, 'UnknownError', e2);
            }
        },
        catchException(e) {
            if (e instanceof Error) {
                Graphics.backupPrintError.call(Graphics, e.name, e);
                console.error(e.stack);
            } else {
                Graphics.backupPrintError.call(Graphics, 'UnknownError', e);
            }
            this.stop();
        },
        // 場景切換自動清理 GC
        changeScene() {
            if (this.isSceneChanging() && !this.isCurrentSceneBusy()) {
                if (this._scene) {
                    this._scene.terminate();
                    this._scene.detachReservation();
                    this._previousClass = this._scene.constructor;
                }

                const differentScene = this._scene && this._scene !== this._nextScene;
                this._scene = this._nextScene;
                if (this._scene) {
                    this._scene.attachReservation();
                    this._scene.create();
                    this._nextScene = null;
                    this._sceneStarted = false;
                    this.onSceneCreate();

                    if (differentScene) {
                        cancelIdleCallback(gcWork);
                        gcWork = requestIdleCallback(() => {
                            Graphics.callGC();
                        }, { timeout: 1e4 });
                    }
                }
                if (this._exiting) {
                    this.terminate();
                }
            }
        }
    });

    // ========== rpg_objects.js ==========

    Game_Battler.prototype.isStateAddable = function (stateId) {
        // ! this._result.isStateRemoved(stateId)  移除了当前回合不允许重复附加状态的限制
        return (this.isAlive() && $dataStates[stateId] &&
            !this.isStateResist(stateId) &&
            !this.isStateRestrict(stateId));
    };

    const old_initMembers = Game_Actor.prototype.initMembers;
    Object.assign(Game_Actor.prototype, {
        initMembers() {
            old_initMembers.call(this);
            this._weaponAmountLimit = 10;  // 武器携带上限
            this._armorAmountLimit = 20;  // 装备携带上限
            this._weaponAmountBonus = 0;  // 额外武器携带上限
            this._armorAmountBonus = 20;  // 额外装备携带上限
        },
        // 修改了脱下装备的逻辑
        discardEquip(item) {
            const slotId = this.equips().indexOf(item);
            if (slotId >= 0) {
                if (DataManager.isWeapon(item)) {
                    this.changeEquip(slotId, $dataWeapons[2]);
                } else if (DataManager.isArmor(item)) {
                    this.changeEquip(slotId, $dataArmors[2]);
                }
            }
        },
        // 原生的步数刷新状态回合
        onPlayerWalk() {
            this.clearResult();
            this.checkFloorEffect();
            if ($gamePlayer.isNormal()) {
                this.states().forEach(function (state) {
                    this.updateStateSteps(state);
                }, this);
                this.showAddedStates();
                this.showRemovedStates();
            }
        },
        // 步数刷新回合
        stepsForTurn() {
            return 1000;
        }
    });

    // 修改了game over判定
    Game_Unit.prototype.isAllDead = function () {
        return $gameActors.actor(1).isStateAffected(1);
    };

    Object.assign(Game_Map.prototype, {
        // 检查玩家有没有受困
        checkPlayerIsPassable() {
            const x = Math.floor($gamePlayer.centerRealX());
            const y = Math.floor($gamePlayer.centerRealY());

            return this.isPassable(x, y, 2) || // 下
                this.isPassable(x, y, 4) || // 左
                this.isPassable(x, y, 6) || // 右
                this.isPassable(x, y, 8);   // 上
        },
        //新增方法，主要用于重置演出事件
        resetMapeventSequence() {
            // 出于防范，重置玩家Z轴高度	
            $gamePlayer.mppHidPasZ = 0;
            // 出于防范，重置玩家举物状态
            $gamePlayer.drill_PT_clearLifting();
            // 出于防范，恢复玩家鼠标操作权限
            $gameSystem._drill_COI_map_mouse = true;
            // 出于防范，重置玩家行走图和移动权限
            $gamePlayer.drill_EASA_setEnabled(true);
            $gameSystem._drill_PAlM_enabled = true;

            // 非特定情况，淡出当前地图bgm
            if (!$gameSwitches.value(40)) {
                AudioManager.fadeOutBgm(2);
            }
            $gameSwitches.setValue(40, false);

            // 淡出可能存在的篝火音效
            if (AudioManager._allBgsBuffer && AudioManager._allBgsBuffer[12]) {
                AudioManager._allBgsBuffer[12].fadeOut(1);
            }
            // 清除旋风斩音效
            if (AudioManager._allBgsBuffer && AudioManager._allBgsBuffer[9]) {
                AudioManager.stopBgsByLine(9);
            }

            // 重置事件开关
            this._events.forEach(function (event) {
                if (event && event.event().note && (event.event().note.includes('<重置独立开关>') || event.event().note.includes('<resetSelfSwitch>'))) {
                    const eventId = event.eventId();
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'A'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'B'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'C'], false);
                    $gameSelfSwitches.setValue([this._mapId, eventId, 'D'], false);
                }
            }, this);

            // 清除图片资源
            const maxPictures = 90;
            for (let pictureId = 3; pictureId <= maxPictures; pictureId++) {
                let picture = $gameScreen.picture(pictureId);
                if (picture) {
                    picture.drill_PCE_stopEffect();
                    $gameScreen.erasePicture(pictureId);
                }
            }

            // 清除图片点击判定
            $gameScreen._pictureCidArray = [];
            $gameScreen._pictureSidArray = [];
            $gameScreen._picturePidArray = [];
            $gameScreen._pictureTransparentArray = [];

            // 清除图片缓存
            // chahuiUtil.freePictureSubdirCache({ ignoreReservation:true, verbose:true });	
        }
    });

    Game_CharacterBase.prototype.animationWait = function () {
        // 新的速度范围是1到64，我们要找到一个新的基准值
        const baseSpeed = 64; // 最大速度
        const speed = this.realMoveSpeed();
        const maxWait = 24; // 原来的最慢速度对应的等待时间
        const minWait = 3; // 原来的最快速度对应的等待时间

        // 由于速度范围变化，我们需要重新计算等待时间的范围
        // 我们假设等待时间与速度成反比
        // 当速度最小时，等待时间最大；速度最大时，等待时间最小
        const waitTime = ((baseSpeed - speed) / (baseSpeed - 1)) * (maxWait - minWait) + minWait;

        return waitTime;
    };

    Object.assign(Game_Player.prototype, {
        // 修改了遇敌事件
        executeEncounter() {
            if (!$gameMap.isEventRunning() && this._encounterCount <= 0) {
                this.makeEncounterCount();
                const commonEventId = this.makeEncounterTroopId() + 299;
                if ($dataCommonEvents[commonEventId] && $dataCommonEvents[commonEventId].name) {
                    $gameTemp.reserveCommonEvent(commonEventId);
                    return false;
                }
            }
            return false;
        },
        // 增加了耐力消耗
        updateDashing() {
            if (this.isMoving()) {
                return;
            }
            if (!this._isPushing && this.canMove() && !this.isInVehicle() && !$gameMap.isDashDisabled()) {
                this._dashing = ConfigManager.alwaysDash || $gameTemp.isDestinationValid();
            } else {
                this._dashing = false;
            }
        }
    });

    Object.assign(Game_Interpreter.prototype, {
        videoFileExt() {
            return '.webm';
        },
        // 避免 class 內嚴格環境下, 解析失敗
        command355() {
            let script = this.currentCommand().parameters[0] + '\n';
            while (this.nextEventCode() === 655) {
                this._index++;
                script += this.currentCommand().parameters[0] + '\n';
            }
            eval(script);
            return true;
        }
    });

    // ========== rpg_scenes.js ==========

    const old_commandNewGame = Scene_Title.prototype.commandNewGame
    Scene_Title.prototype.commandNewGame = function () {
        const audio = {}
        audio.name = '風鈴の音'
        audio.volume = 90
        audio.pitch = 100
        AudioManager.playSe(audio);
        old_commandNewGame.call(this);
    };

    const superclass = Scene_Base.prototype;
    Object.assign(Scene_Map.prototype, {
        // 屏蔽了长按加速功能
        updateMainMultiply() {
            this.updateMain();
        },
        // 修改了地图界面中忙碌状态的判定
        isBusy() {
            if (this._itemWindow) {
                return this._waitCount > 0 || this._encounterEffectDuration > 0 ||
                    superclass.isBusy.call(this);
            } else {
                return ((this._messageWindow && this._messageWindow.isClosing()) ||
                    this._waitCount > 0 || this._encounterEffectDuration > 0 ||
                    superclass.isBusy.call(this));
            }
        },
        terminate() {
            superclass.terminate.call(this);
            if (!SceneManager.isNextScene(Scene_Battle)) {
                this._spriteset.update();
                this._mapNameWindow.hide();
                SceneManager.snapForBackground();
            } else {
                ImageManager.clearRequest();
            }

            if (SceneManager.isNextScene(Scene_Map)) {
                // 新增方法，主要用于重置演出事件
                $gameMap.resetMapeventSequence();
                ImageManager.clearRequest();
            }

            $gameScreen.clearZoom();

            this.removeChild(this._fadeSprite);
            this.removeChild(this._mapNameWindow);
            this.removeChild(this._windowLayer);
            this.removeChild(this._spriteset);
        },
        // 取消鼠标右键打开菜单的功能
        updateCallMenu() {
            if (this.isMenuEnabled()) {
                if (this.menuCalling && !$gamePlayer.isMoving()) {
                    this.callMenu();
                }
            } else {
                this.menuCalling = false;
            }
        }
    });

    // 追加了选项窗口透明度为0
    Scene_Options.prototype.createOptionsWindow = function () {
        this._optionsWindow = new Window_Options();
        this._optionsWindow.setHandler('cancel', this.popScene.bind(this));
        this._optionsWindow.opacity = 0;
        this.addWindow(this._optionsWindow);
    };

    // ========== rpg_windows.js ==========

    // 图标尺寸
    Object.assign(Window_Base, {
        _iconWidth: 64,
        _iconHeight: 64
    });

    Object.assign(Window_Base.prototype, {
        // 竖排版函数
        drawVerticalText(text, x, y) {
            let lineHeight = this.contents.fontSize;
            let characters = text.split('');

            for (let i = 0; i < characters.length; i++) {
                let character = characters[i];
                this.drawText(character, x, y + i * lineHeight);
            }
        },
        // 转义符绘制图标
        processDrawIcon(iconIndex, textState) {
            this.drawIcon(iconIndex, textState.x + 2, textState.y - 2);
            textState.x += Window_Base._iconWidth + 4;
        },
        // 绘制图标的函数
        drawIcon(iconIndex, x, y) {
            const bitmap = ImageManager.loadSystem('IconSet_large');
            const pw = Window_Base._iconWidth;
            const ph = Window_Base._iconHeight;
            const sx = iconIndex % 16 * pw;
            const sy = Math.floor(iconIndex / 16) * ph;
            this.contents.blt(bitmap, sx, sy, pw, ph, x, y);
        },
    });

    // 文本描述栏默认宽度和行数
    Window_Help.prototype.initialize = function (numLines) {
        const width = Graphics.boxWidth;
        const height = this.fittingHeight(numLines || 4);
        Window_Base.prototype.initialize.call(this, 0, 0, width, height);
        this._text = '';
    };

    // 读取玩家选中道具的ID，控制台用
    Window_ItemList.prototype.printItemId = function () {
        const item = this.item();
        if (item) {
            console.log('Selected item ID:', item.id);
        }
    };

    // 阻止修改技能名称、图标的透明度修改
    Window_SkillList.prototype.drawItem = function (index) {
        const skill = this._data[index];
        if (skill) {
            const costWidth = this.costWidth();
            const rect = this.itemRect(index);
            rect.width -= this.textPadding();
            this.drawItemName(skill, rect.x, rect.y, rect.width - costWidth);
            this.drawSkillCost(skill, rect.x, rect.y, rect.width);
            this.changePaintOpacity(1);
        }
    };

    Object.assign(Window_Options.prototype, {
        // 始终冲刺、记住指令功能
        addGeneralOptions() { },
        // BGM、BGS、ME、SE控制
        addVolumeOptions() {
            this.addCommand(TextManager.bgmVolume, 'bgmVolume');
            this.addCommand(TextManager.bgsVolume, 'bgsVolume');
            this.addCommand(TextManager.seVolume, 'seVolume');
        }
    });

    Window_ChoiceList.prototype.select = function (index) {
        Window_Command.prototype.select.call(this, index);
        this._eventRan = false;
    };

})();