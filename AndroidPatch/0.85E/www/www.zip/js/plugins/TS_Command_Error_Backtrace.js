/*:
 * @pluginname Command Error Backtrace
 * @plugindesc Adds an RPG Maker-native stack trace to error messages. (Version 1.0.1)
 *
 * @author Tamschi (tamschi.itch.io)
 *
 * @help
 *
 * ==========
 * Load Order
 * ==========
 *
 * This plugin functions most accurately when placed very late in the load order.
 *
 * ==============
 * Command Syntax
 * ==============
 *
 * This plugin does not add any Plugin Commands.
 *
 * ==============
 * JavaScript API
 * ==============
 *
 * You can set the property TSCommandErrorBacktrace_listName on either the
 * executing Game_Interpreter instance or on the Command list data array
 * itself to provide a custom Command list name for the stack trace.
 * If both are present, the latter takes precedence.
 *
 * When generating, the list name, you can use this snippet to decide whether to
 * include development information in the name:
 *
 * const showNames = ($gameTemp.isPlaytest() ||
 *     PluginManager.parameters('TS_Command_Error_Backtrace')
 *         .showNamesInDeployedGame === "true");
 *
 * ======================
 * Resolved Command Lists
 * ======================
 *
 * Common Event n (<name>)
 * Map n (<name>), Event m (<name>), Page o
 * Troop n (<name>), Page m
 *
 * ===================
 * Compatibility Notes
 * ===================
 *
 * The custom error screen option modifies private RPG Maker functions. As such,
 * the feature may be brittle regarding engine upgrades.
 *
 * Please use caution when upgrading (and please be sure to report any issues, so
 * that I can fix them!).
 *
 * =============
 * License Grant
 * =============
 *
 * This plugin can be downloaded free of charge at
 * https://tamschi.itch.io/command-error-backtrace .
 *
 * Once you have downloaded it from there, you may redistribute and sublicense
 * this plugin file as part of a game. You may not redistribute nor sublicense it
 * separately or as part of an asset- or resource-collection.
 *
 * You may modify this plugin when including it with your game, as long as the
 * attribution above and this license grant stay intact. If you do so, you must
 * add comments to indicate which changes you made from the original.
 *
 * =========
 * Changelog
 * =========
 *
 * -----
 * 1.0.1
 * -----
 *
 * 2022-05-06
 *
 * Fixes:
 * - Added support for Battle Test mode.
 *   (This previously failed due to $dataMap being null.)
 *
 * Revisions:
 * - Log the ignored error as warning when one occurs resolving a Command list.
 *
 * @param customErrorScreen
 * @text Custom Error Screen
 * @type boolean
 * @default true
 * @desc Adjusts the 'Error' screen for easier reading of stack traces, and adds a way to copy the error message.
 * @on ON
 * @off OFF
 *
 * @param showNamesInDeployedGame
 * @text Show names in deployed game?
 * @type boolean
 * @default false
 * @desc Shows (Map, (Common) Event, Troop) names also outside of testing.
 * @on Show names.
 * @off Hide names in deployed game.
*/

    Object.assign(Window_Message.prototype, {
        // 取消了快进会导致等待帧转义字符失效的效果
        updateMessage() {
            if (this._textState) {
                while (!this.isEndOfText(this._textState)) {
                    if (this.needsNewPage(this._textState)) {
                        this.newPage(this._textState);
                    }
                    this.updateShowFast();
                    this.processCharacter(this._textState);
                    // 先看等待/暂停
                    if (this.pause || this._waitCount > 0) {
                        break;
                    }
                    // 再看是否要继续快进
                    if (!this._showFast && !this._lineShowFast) {
                        break;
                    }
                }
                if (this.isEndOfText(this._textState)) {
                    this.onEndOfText();
                }
                return true;
            } else {
                return false;
            }
        },
        // 鼠标长按状态下加速等待帧计时
        updateWait() {
            if (this._waitCount > 0) {
                // 追加单击时无视等待指令
                if (TouchInput.isTriggered()) this._waitCount = 5;
                this._waitCount -= TouchInput.isPressed() ? 2 : 1;
                return true;
            } else {
                return false;
            }
        },
    });

(function () {
  'use strict';

  const parameters = { ...PluginManager.parameters('TS_Command_Error_Backtrace') };
  parameters.showNamesInDeployedGame = parameters.showNamesInDeployedGame === "true";
  parameters.customErrorScreen = parameters.customErrorScreen === "true";

  //────────────────────────────────────────────
  // 扩展 Game_Interpreter 的错误附加堆栈信息
  //────────────────────────────────────────────

  //────────────────────────────────────────────
  // 在错误打印区域追加“Version: x.x.x”
  //────────────────────────────────────────────
  function TSCEB_appendVersion(printer) {
    if (!printer || !$dataSystem) return;
    let ver = "demo";
    // 已插入过就别重复
    if (printer.querySelector('.tsceb-version')) return;

    const p = document.createElement('p');
    let isMobile = "";
    if (Utils.isMobileDevice()) isMobile = "(Android)";
    let match = $dataSystem.gameTitle.match(/ver([\d\.A-Za-z]+)/i);
    if (match) {
      ver = match[1];
    }

    p.className = 'tsceb-version';
    p.style.color = '#ffffff';
    p.style.fontSize = '32px';
    p.style.margin = '8px 0';
    p.textContent = `Current Version: ${ver} ${isMobile}`;
    // 放到第一行错误信息后面、栈追踪前面
    printer.insertBefore(p, printer.children[1] || null);
  }

  function getCurrentScriptForEval(interpreter, index) {
    const list = interpreter._list;
    let i = index;
    if (!list[i] || (list[i].code !== 355 && list[i].code !== 655)) return null;
    // 找到脚本段开头
    while (i > 0 && list[i].code === 655) i--;
    if (list[i].code !== 355) return null;
    // 组合整段script
    let script = list[i].parameters[0] + "\n";
    let j = i + 1;
    while (list[j] && list[j].code === 655) {
      script += list[j].parameters[0] + "\n";
      j++;
    }
    return script;
  }

  const oldUpdateChild = Game_Interpreter.prototype.updateChild;
  Game_Interpreter.prototype.updateChild = function () {
    const index = this._index - 1;
    try {
      return oldUpdateChild.call(this, ...arguments);
    } catch (error) {
      const listId = findListId(this);
      const command = this._list[index];
      let frame = `\n  at ${listId}, line ${index + 1}`;

      if (command && (command.code === 355 || command.code === 655)) {
        const script = getCurrentScriptForEval(this, index);
        if (script) {
          frame += `\n Eval Script:\n${script}`;
        }
      }

      if (error instanceof Error) {
        error.message += frame;
      } else {
        error = new Error(`${error}${frame}`);
      }
      throw error;
    }
  };

  const oldExecuteCommand = Game_Interpreter.prototype.executeCommand;
  Game_Interpreter.prototype.executeCommand = function () {
    const index = this._index;
    try {
      return oldExecuteCommand.call(this, ...arguments);
    } catch (error) {
      const listId = findListId(this);
      const command = this._list[index];
      let frame = `\n  at ${listId}, line ${index + 1}`;

      if (command && (command.code === 355 || command.code === 655)) {
        const script = getCurrentScriptForEval(this, index);
        if (script) {
          frame += `\n Eval Script:\n${script}`;
        }
      }

      if (error instanceof Error) {
        error.message += frame;
      } else {
        error = new Error(`${error}${frame}`);
      }
      throw error;
    }
  };

  /**
   * 根据解释器当前使用的命令列表返回一个简单的来源编号，
   * 不包含地图或公共事件的名称等信息，避免剧透。
   */
  function findListId(interpreter) {
    try {
      // 尝试通过公共事件匹配
      for (const ce of $dataCommonEvents.filter(ce => ce)) {
        if (ce.list === interpreter._list) {
          return "Common Event " + ce.id;
        }
      }
      // 如果 $dataMap 存在，则检查地图事件
      if ($dataMap) {
        for (const event of $dataMap.events.filter(ev => ev)) {
          for (let i = 0; i < event.pages.length; i++) {
            if (event.pages[i].list === interpreter._list) {
              return "Map " + $gameMap.mapId() + ", Event " + event.id + ", Page " + (i + 1);
            }
          }
        }
      }
      return "unknown Command list";
    } catch (error) {
      console.warn("Error while resolving command list source id:", error);
      return "(failed finding source id)";
    }
  }

  //────────────────────────────────────────────
  // 扩展 SceneManager.catchException 错误显示及提示功能
  //────────────────────────────────────────────

  const _SceneManager_catchException = SceneManager.catchException;
  SceneManager.catchException = function (e) {
    _SceneManager_catchException.call(this, e);
    let errorPrinter = document.getElementById("ErrorPrinter");
    //  先插入版本号
    //TSCEB_appendVersion(errorPrinter);

    if (errorPrinter && e.stack) {
      let p = document.createElement("p");
      p.style.color = "white";
      // 只显示简单的堆栈来源信息
      p.innerHTML = "<b>Stack Trace:</b><br>" + ("" + e.stack).replace(/\n/g, "<br>");
      errorPrinter.appendChild(p);
    }
    // 延时 600ms 提示玩家报告 BUG（多语言支持）
    setTimeout(function () {
      // 检测到新版本就提醒去更新
      let RemindToUpdate = $gameStrings.value(1).trim() !== "" || $gameVariables.value(2) !== 0;
      if (RemindToUpdate) {

        let textArray = window.systemFeatureText && window.systemFeatureText.RemindToUpdate;
        if (!textArray) textArray = ["An error has occurred and the game is frozen.",
          "A newer patch is available—",
          "Please use auto-update to fix the issue!"];
        let text = Array.isArray(textArray) ? textArray.join("\n") : (textArray ?? "");
        alert(text);
        location.reload();
      }
    }, 600);
  };

  //────────────────────────────────────────────
  // 如果未启用自定义错误屏幕，则调整旧版错误打印
  //────────────────────────────────────────────

  if (!parameters.customErrorScreen) {
    const oldPrintError = Graphics.printError;
    Graphics.printError = function (name, message, ...args) {
      message = message.replace('\n', "<BR>\n");
      return oldPrintError.call(this, name, message, ...args);
    };
  }


  /** --- patch-begin: Error screen mobile optimisation -------------------- */
  (function () {
    'use strict';

    /**
     * 针对手机横/竖屏做适配：
     * - 顶部对齐，让可用垂直空间最大化
     * - 文字缩小、行间紧凑
     * - 超长内容可滚
     */
    function optimiseErrorPrinter() {
      const ep = document.getElementById('ErrorPrinter');
      if (!ep) return;

      /* 1. 容器布局 */
      ep.style.position = 'fixed';
      ep.style.top = '20%';
      ep.style.left = '50%';
      ep.style.transform = 'translate(-50%,0)';   // 只水平居中
      ep.style.maxWidth = '900vw';
      ep.style.maxHeight = '950vh';
      ep.style.margin = '0';
      ep.style.paddingTop = '8px';


      /* 2. 统一文字样式 */
      const resize = el => {
        el.style.fontSize = '20px';
        el.style.lineHeight = '1.35';
        el.style.margin = '4px 0';
        el.style.wordBreak = 'break-word';
        el.style.whiteSpace = 'pre-wrap';
      };
      ep.querySelectorAll('h2, p, pre').forEach(resize);

      /* 3. 确保版本号那行也跟着变小 */
      const ver = ep.querySelector('.tsceb-version');
      if (ver) resize(ver);
    }

    /* 等 SceneManager.printError / TS_Backtrace 自己把 DOM 建好后再执行 */
    const _Graphics_printError = Graphics.printError;
    Graphics.printError = function () {
      _Graphics_printError.apply(this, arguments);
      optimiseErrorPrinter();
    };

    /* 若使用 SceneManager 自定义 catchException 也打印，则再挂一次 */
    const _SceneManager_catchException = SceneManager.catchException;
    SceneManager.catchException = function () {
      _SceneManager_catchException.apply(this, arguments);
      optimiseErrorPrinter();
    };
  })();
  /** --- patch-end -------------------------------------------------------- */

})();




(function () {
  "use strict";

  // ---- public helper: you may set this somewhere in your boot code
  // window.systemFeatureText = { failedToLoad: ["...line1","...line2"] };

  var _printError = Graphics.printError;
  Graphics.printError = function (name, message) {
    _printError.apply(this, arguments);
    try { enhanceErrorScreen(name, message); } catch (_) { }
  };

  if (Graphics.printLoadingError) {
    var _printLoadingError = Graphics.printLoadingError;
    Graphics.printLoadingError = function (url) {
      _printLoadingError.apply(this, arguments);
      try { enhanceErrorScreen("Loading Error", "Failed to load: " + url); } catch (_) { }
    };
  }

  function enhanceErrorScreen(name, message) {
    const ep = document.getElementById("ErrorPrinter");
    if (!ep) return;

    appendVersion(ep);

    // 仅在“加载失败”类报错时追加底部提示
    const isFailed = /Failed to load/i.test(message) || /Loading Error/i.test(name);
    if (isFailed) appendFailedTip(ep);
  }

  function appendVersion(ep) {
    if (ep.querySelector(".qj-version")) return;

    let ver = "";
    // 1) 从 System 标题里解析 “verX.X.X”
    if (window.$dataSystem && $dataSystem.gameTitle) {
      const m = $dataSystem.gameTitle.match(/ver\s*([A-Za-z0-9._-]+)/i);
      if (m) ver = m[1];
    }
    // 2) 兜底：从 document.title 里再试一次
    if (!ver && document.title) {
      const m2 = document.title.match(/ver\s*([A-Za-z0-9._-]+)/i);
      if (m2) ver = m2[1];
    }
    // 设备标记
    const suffix = (window.Utils && Utils.isMobileDevice()) ? " (Android)" : "";

    const p = document.createElement("p");
    p.className = "qj-version";
    p.style.color = "#ffffff";
    p.style.fontSize = "28px";
    p.style.margin = "8px 0";
    p.textContent = "Current Version: " + (ver || "") + suffix;
    ep.insertBefore(p, ep.children[1] || null);
  }

  function appendFailedTip(ep) {
    if (ep.querySelector(".qj-failed-tip")) return;

    // 取多语言文本：数组优先，字符串就按换行切
    let lines = window.systemFeatureText && window.systemFeatureText.failedToLoad;
    if (!lines) {
      lines = [
        "This kind of issue may be caused by:",
        "① Game files corrupted or filenames garbled due to encoding issues during extraction/installation.",
        "② The developer forgetting to include the file—please wait for a patch update to fix it."
      ];
    }
    if (!Array.isArray(lines)) lines = String(lines).split(/\r?\n/);

    // 外层容器（替代原来的单个 <p>）
    const wrap = document.createElement("div");
    wrap.className = "qj-failed-tip";
    wrap.style.color = "#ffffff";
    wrap.style.marginTop = "24px";
    wrap.style.whiteSpace = "pre-wrap";
    wrap.style.lineHeight = "1.5"; // 

    lines.forEach((line, i) => {
      const d = document.createElement("div");
      d.textContent = line;

      if (/^(②|2\.|\(2\))/.test(line)) {
        d.style.textDecoration = "line-through";
      }
      wrap.appendChild(d);
    });

    ep.appendChild(wrap);
  }


})();



/*:
 * - 保持原生错误流程：SceneManager.catchException -> Graphics.printError -> SceneManager.stop()
 * - 错误出现时：屏幕显示“继续游戏”按钮；按 Z / Enter / Space 也可返回（推荐）。
 * - 返回时：隐藏 ErrorPrinter、清滤镜/禁点、仅跳过出错那一条事件指令、短 rAF 拉起循环。
 * - 自动更新优先：若 window.__TSCEB_autoUpdatePending===true，将不响应返回操作。
 */

(function () {
  'use strict';

/**
 * @static
 * @method _updateErrorPrinter
 * @private
 */
// 固定样式：模板字符串写法


Graphics._updateErrorPrinter = function () {
  const ep = this._errorPrinter;
  if (!ep) return;

  const TSCEB_ERROR_CSS = `
    position: fixed;
    left: 0; top: 0; right: 0; bottom: 0;
    margin: 0;
    width: 100vw; height: 100vh;
    box-sizing: border-box;
    display: flex; flex-direction: column;
    align-items: center; justify-content: center;
    padding: 2vh 4vw;
    text-align: center;
    text-shadow: 1px 1px 3px #000;
    font-size: clamp(14px, 2.2vmin, 20px);
    pointer-events: auto;
    overflow: auto;
    transform: none; -webkit-transform: none;
    z-index: 1000; 
  `;

  // 只在第一次写入，避免重复触发布局
  if (ep.__tsceb_cssApplied !== true) {
    ep.style.cssText = TSCEB_ERROR_CSS;
    ep.__tsceb_cssApplied = true;
  }
};




  // =====================================================================================
  // A) 记录“出错点”的解释器与指令索引
  // =====================================================================================
  if (!window.__TSCEB_trace_hooked) {
    window.__TSCEB_trace_hooked = true;
    const _exec = Game_Interpreter.prototype.executeCommand;
    Game_Interpreter.prototype.executeCommand = function () {
      try {
        return _exec.apply(this, arguments);
      } catch (e) {
        // 记录最近一次的异常现场
        window.__TSCEB_lastFault = {
          interpreter: this,
          listRef: this._list,
          index: this._index
        };
        throw e; // 让引擎按原生流程显示错误 + 停循环
      }
    };
  }

  // =====================================================================================
  // B) 包装 catchException：仅保存 Error 对象引用（不改变原生行为）
  // =====================================================================================
  (function wrapCatchException() {
    const _catch = SceneManager.catchException;
    SceneManager.catchException = function (e) {
      try { window.__TSCEB_lastError = (e instanceof Error) ? e : null; } catch (_) { }
      return _catch.apply(this, arguments);
    };
  })();

  // =====================================================================================
  // C) 包装 printError：确保错误面板存在且可见；附加“继续游戏”按钮与提示
  //     同时临时关闭 #MousePointer 的点击
  // =====================================================================================
  (function wrapPrintError() {
    let btn = null; // ? 宣告在外部，防止被垃圾回收 (也可以每次重新創建, 看是在意 GC 還是在意性能)

    const _print = Graphics.printError;
    Graphics.printError = function (name, message) {

      try {
        // ? 臨時演示寫法, 用於緩存 bgmBuffer, 報錯時通常會被重置
        // ? 需要注意場景播放的 bgm, 是來自哪裡的, 並不一定每次 _bgmBuffer 都是對的, 另外就是選擇紀錄 播放的時間進度, 根據時間還原
        //window.cache_bgmBuffer = AudioManager._bgmBuffer;

        _print.apply(this, arguments);

        // this._errorShowed = true;
        // if (this._errorPrinter) {
        //   this._errorPrinter.innerHTML = this._makeErrorHtml(name, message);
        // }
        // this._applyCanvasFilter();
        // this._clearUpperCanvas();

        // 确保可见 & 可交互（某些主题会把错误层置灰/禁点）
        const ep = this._errorPrinter;
        if (!ep.style.color) ep.style.color = '#fff';

        Object.assign(ep.style, {
          zIndex: 1000,
          display: 'block',
          pointerEvents: 'auto'
        });

        // 🔒 关闭全屏鼠标捕获层（如 #MousePointer）的点击
        // disableMousePointerClicks();

        // 若没有“继续游戏”按钮则补一个（点击可能被拦截，键盘兜底）
        if (!btn) { // ? 沒有時進行賦予
          btn = document.createElement('button');
          btn.className = 'tsceb-btn-continue';
          btn.textContent = (window.systemFeatureText && systemFeatureText.backToGame)
            ? (Array.isArray(systemFeatureText.backToGame) ? systemFeatureText.backToGame[0] : systemFeatureText.backToGame)
            : '▶ 点击继续游戏 / Click to continue the game';
          btn.style.cssText = `
            font-size: 16px;
            padding: 8px 12px;
            border-radius: 10px;
            border: 1px solid #fff;
            background: rgba(0,0,0,0.25);
            color: #fff;
            cursor: pointer;
            touch-action: manipulation;
            margin-top: 12px;
            display: inline-block
          `;
          btn.addEventListener('pointerup', function (e) {
            try { window?.__TSCEB_returnToGameFromError(); } catch { }
          })
        };

        ep.appendChild(btn); // ? 後續直接添加
      } catch (err) {
        console.warn('[TSCEB] post-printError failed:', err);
      }
    };
  })();

  // =====================================================================================
  // D) 返回游戏：隐藏面板、撤销滤镜/禁点、仅跳过出错指令、短 rAF 拉起循环
  //     —— 不删除 _errorPrinter，保证下次 printError 能正常复用与显示
  // =====================================================================================
  window.__TSCEB_returnToGameFromError ??= function () {
    // 自动更新优先：进行中则不允许返回
    if (window.__TSCEB_autoUpdatePending) { try { navigator.vibrate && navigator.vibrate(10); } catch { } return; }

    try {
      // 0) 隐藏错误面板（不要 remove）
      try {
        Graphics._errorShowed = false;
        Object.assign(Graphics._errorPrinter.style, {
          zIndex: 1000,
          display: 'none',
          pointerEvents: 'none'
        });
      } catch { }

      // ✅ 恢复之前被禁用的 #MousePointer 点击
      // restoreMousePointerClicks();

      // 1) 撤销 Graphics._applyCanvasFilter 带来的视觉锁

      Object.assign(Graphics._canvas.style, {
        opacity: 1,
        filter: 'none',
        webkitFilter: 'none',
      });

      // function clearLocks(el) {
      //   if (!el || !el.style) return;
      //   el.style.filter = 'none';
      //   el.style.webkitFilter = 'none';
      //   el.style.backdropFilter = 'none';
      //   el.style.webkitBackdropFilter = 'none';
      //   el.style.opacity = '1';
      //   el.style.pointerEvents = 'auto';
      // }
      // clearLocks(document.body);
      // document.querySelectorAll('canvas, body > *').forEach(clearLocks);

      SceneManager.resume();
      // SceneManager._stopped = false;
      // SceneManager.requestUpdate();

      // (有的話) 恢復 BGM
      //AudioManager._bgmBuffer = window.cache_bgmBuffer // 添加回原始物件 避免意外
      //AudioManager._bgmBuffer?.play();
      //window.cache_bgmBuffer = null; // 手動釋放 GC

      // (有的話) 恢復 Video
      Graphics._video?.play();

      
      // 2) 仅跳过“出错的那一条事件指令”
      (function skipOnce() {
        const info = window.__TSCEB_lastFault;
        if (!info || !info.interpreter) return;
        const it = info.interpreter;

        if (!it._list || !Array.isArray(it._list) || it._list.length === 0) return;
        if (info.listRef && info.listRef !== it._list) return; // 事件已切换/结束

        // 终止子解释器（避免卡在旧状态）
        try {
          if (it._childInterpreter) {
            it._childInterpreter.terminate && it._childInterpreter.terminate();
            it._childInterpreter.clear && it._childInterpreter.clear();
            it._childInterpreter = null;
          }
        } catch (_) { }

        const next = Math.min(
          (typeof info.index === 'number' ? info.index + 1 : it._index + 1),
          it._list.length
        );
        it._index = next;

        // 只跳一次，清记录
        window.__TSCEB_lastFault = null;
      })();

      // 3) 用短 rAF 驱动把循环拉起来（SceneManager.stop() 之后必需）
	  /*
      window.__tsceb_rescueRAF && cancelAnimationFrame(window.__tsceb_rescueRAF);
      const t0 = performance.now();
      (function loop() {
        try { SceneManager._stopped = false; SceneManager.update(); }
        catch (e) { console.warn('[tsceb-rescue-loop]', e); }
        if (performance.now() - t0 < 1500) {
          window.__tsceb_rescueRAF = requestAnimationFrame(loop);
        }
      })();
      */
	  
      // 4) 可选：恢复媒体（忽略失败）
      //try { if (Graphics._video && Graphics._video.play) Graphics._video.play().catch(() => { }); } catch (_) { }
      //try { if (AudioManager && AudioManager._bgmBuffer && AudioManager._bgmBuffer.resume) AudioManager._bgmBuffer.resume(); } catch (_) { }
      Graphics.hideFps();
    } catch (e) {
      console.warn('[TSCEB] returnToGameFromError failed:', e);
    }
  };
  /*
  // =====================================================================================
  // E) 键盘触发（捕获阶段）：Z / Enter / Space；仅在错误态时响应
  // =====================================================================================
  if (!window.__tsceb_key_bound_min) {
    window.__tsceb_key_bound_min = true;
    window.addEventListener('keydown', function (e) {
      if (window.__TSCEB_autoUpdatePending) return;

      // 错误态：面板可见 或 _errorShowed / _stopped 标记为真
      const ep = document.getElementById('ErrorPrinter');
      const panelVisible = !!(ep && ep.style.display !== 'none');
      const inError =
        panelVisible ||
        (function () { try { return !!Graphics._errorShowed; } catch (_) { return false; } })() ||
        (function () { try { return !!SceneManager._stopped; } catch (_) { return false; } })();
      if (!inError) return;

      const k = e.key, code = e.code;
      // 只留 Z/Enter/Space（如需仅 Z，把后两项移除即可）
      const hit = (k === 'z' || k === 'Z' || code === 'KeyZ' || k === 'Enter' || k === ' ' || code === 'Space');
      if (!hit) return;

      e.preventDefault();
      e.stopImmediatePropagation();
      try { window.__TSCEB_returnToGameFromError && window.__TSCEB_returnToGameFromError(); } catch (_) { }
    }, true);
  }
  */
})();
