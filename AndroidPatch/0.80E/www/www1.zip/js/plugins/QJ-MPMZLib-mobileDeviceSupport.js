//=============================================================================
 /*:
 * @plugindesc 移动设备适配用脚本
 * @author shiroin
 */
//=============================================================================
var QJ = QJ || {};
QJ.VB = QJ.VB || {};

var chahuiUtil = chahuiUtil || {};
// 根据用户端跳转Discord
chahuiUtil.jumpToDiscordServer = function () {
	
		if ( Utils.isMobileDevice() ) {
            window.open('https://docs.google.com/spreadsheets/d/1fDTga-dhWarmZjoPLGN9X85UqCQwDj1L9NpInVcVVLE/edit?usp=sharing', '_system');
           } else {
            require('nw.gui').Shell.openExternal('https://docs.google.com/spreadsheets/d/1fDTga-dhWarmZjoPLGN9X85UqCQwDj1L9NpInVcVVLE/edit?usp=sharing');
        }
				
};

// 根据条件切换虚拟按键
QJ.MPMZ.tl._setDirButtonMode = function() { 
   
   if (QJ && QJ.VB && QJ.VB.readyVirtualButton) {
     const dirBtn = QJ.VB.findDirButton();
     if (dirBtn) {
       const targetMode = $gameMessage.isChoice() ? 0 : 2;
       if (dirBtn._dirMode !== targetMode) {
         ConfigManager.VBData.dirMode = targetMode;
         // 强制自身重建一次
         dirBtn.changeDirMode(targetMode);
       }
     }
   }
};


// 根据条件切换虚拟按键
QJ.VB.showFastForwardButton = function() { 
   var messageWindow = SceneManager._scene && SceneManager._scene._messageWindow && SceneManager._scene._messageWindow.isOpen() && !$gameMessage.isChoice();
   return messageWindow;
};


/*
// 移动端专用-快进键
QJ.MPMZ.tl._imoutoUtilFastForwardButton = function() {
	
	window._forceMsgSkip = false;
    var fastForward = QJ.MPMZ.Shoot({
        img:"imoutoUtil/icon_fastForward",
		groupName:['mobileDevice','fastForwardButton'],
        position:[['S',110],['S',990]],
        initialRotation:['S',0],
        imgRotation:['F'],
        collisionBox:['C',55],
        moveType:['D',false],
		opacity:0,
		z:"A",
        existData:[	
        ],
		moveJS:[
		   [12,12,"let value = 0;if($gameMessage.hasText()&&!$gameMessage.isChoice()){value = 1;}this.changeAttribute('opacity',value)"],
		   [12,12,"if(TouchInput.isPressed()&&!this._activated){QJ.MPMZ.rangeAtk([['M'],['M']],['B','fastForwardButton'],['S','bulletTarget._activated=true'],['C',2])}"]
		],		
		moveF:[
		   [12,12,QJ.MPMZ.tl._imoutoUtilFastForwardButtonEffect]
		],
    });		
};

// 移动端专用-返回键
QJ.MPMZ.tl._imoutoUtilReturnButton = function() {
	
    var returnIcon = QJ.MPMZ.Shoot({
        img:"imoutoUtil/icon_return",
		groupName:['mobileDevice','returnButton'],
        position:[['S',110],['S',990]],
        initialRotation:['S',0],
        imgRotation:['F'],
        collisionBox:['C',55],
        moveType:['D',false],
		opacity:0,
		z:"A",
        existData:[	
        ],
		moveJS:[
		   [40,12,"let value = 0;if($gameMessage.isChoice()||$gameMessage.isItemChoice()){value = 1;}this.changeAttribute('opacity',value)"]		   
		],		
		moveF:[
		   [12,12,QJ.MPMZ.tl._imoutoUtilReturnButtonEffect]
		],
    });		
};

QJ.MPMZ.tl._imoutoUtilReturnButtonEffect = function() {

    if (this._returned) {
		this._returned = false;
		Input._currentState['cancel'] = false;
	}
	
	if (this.opacity > 0.9) {
      if(TouchInput.isPressed()) {
		  let triggered = QJ.MPMZ.rangeAtk([['M'],['M']],['B','returnButton'],['S',"Input._currentState['cancel'] = true"],['C',2]).length;
		  if (triggered > 0) {
            //SoundManager.playCancel();
            this._returned = true;			
		  }
	   }		
	}
};

QJ.MPMZ.tl._imoutoUtilFastForwardButtonEffect = function() {
  if (this.opacity > 0.9) {
    if (TouchInput.isPressed()) {
      if (!this._activated) {
        QJ.MPMZ.rangeAtk(
          [['M'], ['M']],
          ['B', 'fastForwardButton'],
          ['S', 'bulletTarget._activated=true;TouchInput._screenPressed=false'],
          ['C', 2]
        );
      } else {
        QJ.MPMZ.rangeAtk(
          [['M'], ['M']],
          ['B', 'fastForwardButton'],
          ['S', 'bulletTarget._activated=false;TouchInput._screenPressed=false'],
          ['C', 2]
        );
      }

      if (!this._activated) {
        window._forceMsgSkip = false;
        this._activated = false;
        if (this._iconChange) {
          this._iconChange = false;
          this.changeAttribute("img", "imoutoUtil/icon_fastForward");
          SoundManager.playCancel();
        }
        return;
      }

      if (this._activated) {
        if (!this._iconChange) {
          this._iconChange = true;
          this.changeAttribute("img", "imoutoUtil/icon_fastForward_active");
          SoundManager.playOk();
          window._forceMsgSkip = true;
        }
      }
    }
  } else {
    window._forceMsgSkip = false;
    this._activated = false;
    if (this._iconChange) {
      this._iconChange = false;
      this.changeAttribute("img", "imoutoUtil/icon_fastForward");
    }
  }
};
*/

/*
为游戏标题增加版本标记
*/
(function() {

  if (!Utils.isMobileDevice()) return;
	
  const FONT_FACE   = "MPLUS2ExtraBold";
  const FONT_SIZE   = 28;
  const PADDING_X   = 20;                // 距左侧
  const PADDING_Y   = 20;                // 距底部
  const COLOR       = "#d3d2d2";
  const OUTLINE_COL = "rgba(0,0,0,0.9)";
  const OUTLINE_W   = 3;

  const SHOW_FALLBACK  = true;          // 没匹配到是否仍显示默认文本
  const FALLBACK_TEXT  = "Wrong Version";             // 没匹配到时显示的文字（SHOW_FALLBACK=true时生效）

  function extractVersionFromTitle(title) {
    if (!title) return null;

    // 优先匹配 "ver..."
    let m = title.match(/(ver\s*\d[\w.\-]*)/i);
    if (m && m[1]) {
      // 规范化空格：去掉 ver 与数字之间的空格 → "ver0.75"
      return m[1].replace(/\s+/g, "").replace(/^VER/i, "✦Ver");
    }

    return null;
  }

  function drawVersionOnTitle(scene) {
    const bmp = scene._gameTitleSprite && scene._gameTitleSprite.bitmap;
    if (!bmp) return;

    const title = ($dataSystem && $dataSystem.gameTitle) || "";
    let text = extractVersionFromTitle(title);
    if (!text) {
      if (!SHOW_FALLBACK || !FALLBACK_TEXT) return;
      text = FALLBACK_TEXT;
    }

    const x = PADDING_X;
    const lineH = FONT_SIZE + 8;
    const y = Graphics.height - (PADDING_Y + lineH);

    // 备份
    const pf  = bmp.fontFace;
    const pz  = bmp.fontSize;
    const pc  = bmp.textColor;
    const poc = bmp.outlineColor;
    const pow = bmp.outlineWidth;

    // 设置字体与颜色
    bmp.fontFace     = FONT_FACE;
    bmp.fontSize     = FONT_SIZE;
    bmp.textColor    = COLOR;

    // 关闭描边
    bmp.outlineWidth = 0;
    bmp.outlineColor = "rgba(0,0,0,0)";

    // 关闭阴影（直接操作 Canvas2D 上下文）
    if (bmp._context) {
      const ctx = bmp._context;
      ctx.shadowColor   = "rgba(0,0,0,0)";
      ctx.shadowBlur    = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }

    bmp.drawText(text, x, y, Graphics.width - x * 2, lineH, "left");
    bmp._setDirty && bmp._setDirty();

    // 还原
    bmp.fontFace     = pf;
    bmp.fontSize     = pz;
    bmp.textColor    = pc;
    bmp.outlineColor = poc;
    bmp.outlineWidth = pow;
  }

  const _Title_createForeground = Scene_Title.prototype.createForeground;
  Scene_Title.prototype.createForeground = function() {
    _Title_createForeground.call(this);
    drawVersionOnTitle(this);
  };
})();




var Grover = Grover || {};
Grover.gameOptimization = Grover.gameOptimization || {};
Grover.gameOptimization.PRECISION_FRAGMENT_OPTIMIZATION = "true";

(function() {
"use strict"
let grover_game_optimization;
const __exports = {};
let wasm;

const heap = new Array(32).fill(undefined);

heap.push(undefined, null, true, false);

function getObject(idx) { return heap[idx]; }

let heap_next = heap.length;

function dropObject(idx) {
    if (idx < 36) return;
    heap[idx] = heap_next;
    heap_next = idx;
}

function takeObject(idx) {
    const ret = getObject(idx);
    dropObject(idx);
    return ret;
}

let WASM_VECTOR_LEN = 0;

let cachegetUint8Memory0 = null;
function getUint8Memory0() {
    if (cachegetUint8Memory0 === null || cachegetUint8Memory0.buffer !== wasm.memory.buffer) {
        cachegetUint8Memory0 = new Uint8Array(wasm.memory.buffer);
    }
    return cachegetUint8Memory0;
}

let cachedTextEncoder = new TextEncoder('utf-8');

const encodeString = (typeof cachedTextEncoder.encodeInto === 'function'
    ? function (arg, view) {
    return cachedTextEncoder.encodeInto(arg, view);
}
    : function (arg, view) {
    const buf = cachedTextEncoder.encode(arg);
    view.set(buf);
    return {
        read: arg.length,
        written: buf.length
    };
});

function passStringToWasm0(arg, malloc, realloc) {

    if (realloc === undefined) {
        const buf = cachedTextEncoder.encode(arg);
        const ptr = malloc(buf.length);
        getUint8Memory0().subarray(ptr, ptr + buf.length).set(buf);
        WASM_VECTOR_LEN = buf.length;
        return ptr;
    }

    let len = arg.length;
    let ptr = malloc(len);

    const mem = getUint8Memory0();

    let offset = 0;

    for (; offset < len; offset++) {
        const code = arg.charCodeAt(offset);
        if (code > 0x7F) break;
        mem[ptr + offset] = code;
    }

    if (offset !== len) {
        if (offset !== 0) {
            arg = arg.slice(offset);
        }
        ptr = realloc(ptr, len, len = offset + arg.length * 3);
        const view = getUint8Memory0().subarray(ptr + offset, ptr + len);
        const ret = encodeString(arg, view);

        offset += ret.written;
    }

    WASM_VECTOR_LEN = offset;
    return ptr;
}

function isLikeNone(x) {
    return x === undefined || x === null;
}

let cachegetInt32Memory0 = null;
function getInt32Memory0() {
    if (cachegetInt32Memory0 === null || cachegetInt32Memory0.buffer !== wasm.memory.buffer) {
        cachegetInt32Memory0 = new Int32Array(wasm.memory.buffer);
    }
    return cachegetInt32Memory0;
}

let cachedTextDecoder = new TextDecoder('utf-8', { ignoreBOM: true, fatal: true });

cachedTextDecoder.decode();

function getStringFromWasm0(ptr, len) {
    return cachedTextDecoder.decode(getUint8Memory0().subarray(ptr, ptr + len));
}

function makeMutClosure(arg0, arg1, dtor, f) {
    const state = { a: arg0, b: arg1, cnt: 1, dtor };
    const real = (...args) => {
        // First up with a closure we increment the internal reference
        // count. This ensures that the Rust closure environment won't
        // be deallocated while we're invoking it.
        state.cnt++;
        const a = state.a;
        state.a = 0;
        try {
            return f(a, state.b, ...args);
        } finally {
            if (--state.cnt === 0) {
                wasm.__wbindgen_export_2.get(state.dtor)(a, state.b);

            } else {
                state.a = a;
            }
        }
    };
    real.original = state;

    return real;
}

function addHeapObject(obj) {
    if (heap_next === heap.length) heap.push(heap.length + 1);
    const idx = heap_next;
    heap_next = heap[idx];

    heap[idx] = obj;
    return idx;
}
function __wbg_adapter_14(arg0, arg1, arg2) {
    wasm._dyn_core__ops__function__FnMut__A____Output___R_as_wasm_bindgen__closure__WasmClosure___describe__invoke__h6083e0f02cc77f52(arg0, arg1, addHeapObject(arg2));
}

/**
* @returns {Promise<void>}
*/
__exports.run = function() {
    wasm.run();
};

function handleError(f, args) {
    try {
        return f.apply(this, args);
    } catch (e) {
        wasm.__wbindgen_exn_store(addHeapObject(e));
    }
}

async function load(module, imports) {
    if (typeof Response === 'function' && module instanceof Response) {
        if (typeof WebAssembly.instantiateStreaming === 'function') {
            try {
                return await WebAssembly.instantiateStreaming(module, imports);

            } catch (e) {
                if (module.headers.get('Content-Type') != 'application/wasm') {
                    console.warn("`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n", e);

                } else {
                    throw e;
                }
            }
        }

        const bytes = await module.arrayBuffer();
        return await WebAssembly.instantiate(bytes, imports);

    } else {
        const instance = await WebAssembly.instantiate(module, imports);

        if (instance instanceof WebAssembly.Instance) {
            return { instance, module };

        } else {
            return instance;
        }
    }
}

async function init(input) {
    if (typeof input === 'undefined') {
        let src;
        if (typeof document === 'undefined') {
            src = location.href;
        } else {
            src = document.currentScript.src;
        }
        input = src.replace(/\.js$/, '_bg.wasm');
    }
    const imports = {};
    imports.wbg = {};
    imports.wbg.__wbindgen_object_drop_ref = function(arg0) {
        takeObject(arg0);
    };
    imports.wbg.__wbindgen_string_get = function(arg0, arg1) {
        const obj = getObject(arg1);
        var ret = typeof(obj) === 'string' ? obj : undefined;
        var ptr0 = isLikeNone(ret) ? 0 : passStringToWasm0(ret, wasm.__wbindgen_malloc, wasm.__wbindgen_realloc);
        var len0 = WASM_VECTOR_LEN;
        getInt32Memory0()[arg0 / 4 + 1] = len0;
        getInt32Memory0()[arg0 / 4 + 0] = ptr0;
    };
    imports.wbg.__wbg_log_22d8a7c02023bdb8 = function(arg0, arg1, arg2, arg3) {
        console.log(getStringFromWasm0(arg0, arg1), getStringFromWasm0(arg2, arg3));
    };
    imports.wbg.__wbindgen_boolean_get = function(arg0) {
        const v = getObject(arg0);
        var ret = typeof(v) === 'boolean' ? (v ? 1 : 0) : 2;
        return ret;
    };
    imports.wbg.__wbindgen_cb_drop = function(arg0) {
        const obj = takeObject(arg0).original;
        if (obj.cnt-- == 1) {
            obj.a = 0;
            return true;
        }
        var ret = false;
        return ret;
    };
    imports.wbg.__wbg_newnoargs_be86524d73f67598 = function(arg0, arg1) {
        var ret = new Function(getStringFromWasm0(arg0, arg1));
        return addHeapObject(ret);
    };
    imports.wbg.__wbg_call_888d259a5fefc347 = function() { return handleError(function (arg0, arg1) {
        var ret = getObject(arg0).call(getObject(arg1));
        return addHeapObject(ret);
    }, arguments) };
    imports.wbg.__wbg_eval_a8662911f1f95234 = function() { return handleError(function (arg0, arg1) {
        var ret = eval(getStringFromWasm0(arg0, arg1));
        return addHeapObject(ret);
    }, arguments) };
    imports.wbg.__wbg_resolve_d23068002f584f22 = function(arg0) {
        var ret = Promise.resolve(getObject(arg0));
        return addHeapObject(ret);
    };
    imports.wbg.__wbg_then_2fcac196782070cc = function(arg0, arg1) {
        var ret = getObject(arg0).then(getObject(arg1));
        return addHeapObject(ret);
    };
    imports.wbg.__wbindgen_throw = function(arg0, arg1) {
        throw new Error(getStringFromWasm0(arg0, arg1));
    };
    imports.wbg.__wbindgen_rethrow = function(arg0) {
        throw takeObject(arg0);
    };
    imports.wbg.__wbindgen_closure_wrapper42 = function(arg0, arg1, arg2) {
        var ret = makeMutClosure(arg0, arg1, 15, __wbg_adapter_14);
        return addHeapObject(ret);
    };

    if (typeof input === 'string' || (typeof Request === 'function' && input instanceof Request) || (typeof URL === 'function' && input instanceof URL)) {
        input = fetchLocal(input);
    }

    function fetchLocal(url) {
      var xhr = new XMLHttpRequest();
      xhr.responseType = "arraybuffer";
      return new Promise(function (resolve, reject) {
        xhr.onload = function () {
          resolve(
            new Response(xhr.response, {
              status: xhr.status,
              headers: new Headers({ "Content-Type": "application/wasm" })
            })
          );
        };
        xhr.onerror = function () {
          reject(new TypeError("Local request failed"));
        };
        xhr.open("GET", url);
        xhr.send(null);
      });
    }

    const { instance, module } = await load(await input, imports);

    wasm = instance.exports;
    init.__wbindgen_wasm_module = module;
    wasm.__wbindgen_start();
    return wasm;
}

grover_game_optimization = Object.assign(init, __exports);
grover_game_optimization(document.currentScript.src.replace(".js", "_Pack"))
.then(function(){})
.catch(function() {console.error("江枫眠游戏优化插件发生异常!可能是WebView不支持使用!")});
})();