//=============================================================================
 /*:
 * @plugindesc 移动设备适配用脚本
 * @author shiroin
 */
//=============================================================================
var QJ = QJ || {};
QJ.VB = QJ.VB || {};

var chahuiUtil = chahuiUtil || {};
// 根据用户端跳转Discord
chahuiUtil.jumpToDiscordServer = function () {
	
		if ( Utils.isMobileDevice() ) {
            window.open('https://docs.google.com/spreadsheets/d/1fDTga-dhWarmZjoPLGN9X85UqCQwDj1L9NpInVcVVLE/edit?usp=sharing', '_system');
           } else {
            require('nw.gui').Shell.openExternal('https://docs.google.com/spreadsheets/d/1fDTga-dhWarmZjoPLGN9X85UqCQwDj1L9NpInVcVVLE/edit?usp=sharing');
        }
				
};

// 根据条件切换虚拟按键
QJ.MPMZ.tl._setDirButtonMode = function() { 
   
   if (QJ && QJ.VB && QJ.VB.readyVirtualButton) {
     const dirBtn = QJ.VB.findDirButton();
     if (dirBtn) {
       const targetMode = $gameMessage.isChoice() ? 0 : 2;
       if (dirBtn._dirMode !== targetMode) {
         ConfigManager.VBData.dirMode = targetMode;
         // 强制自身重建一次
         dirBtn.changeDirMode(targetMode);
       }
     }
   }
};


// 根据条件切换虚拟按键
QJ.VB.showFastForwardButton = function() { 
   var messageWindow = SceneManager._scene && SceneManager._scene._messageWindow && SceneManager._scene._messageWindow.isOpen() && !$gameMessage.isChoice();
   return messageWindow;
};


/*
为游戏标题增加版本标记
*/
(function() {

  if (!Utils.isMobileDevice()) return;
	
  const FONT_FACE   = "MPLUS2ExtraBold";
  const FONT_SIZE   = 28;
  const PADDING_X   = 20;                // 距左侧
  const PADDING_Y   = 20;                // 距底部
  const COLOR       = "#d3d2d2";
  const OUTLINE_COL = "rgba(0,0,0,0.9)";
  const OUTLINE_W   = 3;

  const SHOW_FALLBACK  = true;          // 没匹配到是否仍显示默认文本
  const FALLBACK_TEXT  = "Wrong Version";             // 没匹配到时显示的文字（SHOW_FALLBACK=true时生效）

  function extractVersionFromTitle(title) {
    if (!title) return null;

    // 优先匹配 "ver..."
    let m = title.match(/(ver\s*\d[\w.\-]*)/i);
    if (m && m[1]) {
      // 规范化空格：去掉 ver 与数字之间的空格 → "ver0.75"
      return m[1].replace(/\s+/g, "").replace(/^VER/i, "✦Ver");
    }

    return null;
  }

  function drawVersionOnTitle(scene) {
    const bmp = scene._gameTitleSprite && scene._gameTitleSprite.bitmap;
    if (!bmp) return;

    const title = ($dataSystem && $dataSystem.gameTitle) || "";
    let text = extractVersionFromTitle(title);
    if (!text) {
      if (!SHOW_FALLBACK || !FALLBACK_TEXT) return;
      text = FALLBACK_TEXT;
    }

    const x = PADDING_X;
    const lineH = FONT_SIZE + 8;
    const y = Graphics.height - (PADDING_Y + lineH);

    // 备份
    const pf  = bmp.fontFace;
    const pz  = bmp.fontSize;
    const pc  = bmp.textColor;
    const poc = bmp.outlineColor;
    const pow = bmp.outlineWidth;

    // 设置字体与颜色
    bmp.fontFace     = FONT_FACE;
    bmp.fontSize     = FONT_SIZE;
    bmp.textColor    = COLOR;

    // 关闭描边
    bmp.outlineWidth = 0;
    bmp.outlineColor = "rgba(0,0,0,0)";

    // 关闭阴影（直接操作 Canvas2D 上下文）
    if (bmp._context) {
      const ctx = bmp._context;
      ctx.shadowColor   = "rgba(0,0,0,0)";
      ctx.shadowBlur    = 0;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 0;
    }

    bmp.drawText(text, x, y, Graphics.width - x * 2, lineH, "left");
    bmp._setDirty && bmp._setDirty();

    // 还原
    bmp.fontFace     = pf;
    bmp.fontSize     = pz;
    bmp.textColor    = pc;
    bmp.outlineColor = poc;
    bmp.outlineWidth = pow;
  }

  const _Title_createForeground = Scene_Title.prototype.createForeground;
  Scene_Title.prototype.createForeground = function() {
    _Title_createForeground.call(this);
    drawVersionOnTitle(this);
  };
})();



/* ===== Canvas WRF 黑名单（安全包装版；不重写 _createCanvas 本体） ===== */
(function(){
  if (!Utils.isMobileDevice()) return;	
  // 1) 改 getContext：若处于“跳过WRF”窗口，或画布被标记为 _noWRF，就完全不改参数
  var ORIG_GET = HTMLCanvasElement.prototype.getContext;
  var SKIP_WRF = 0; // >0 时，本次 getContext 不加 willReadFrequently

  HTMLCanvasElement.prototype.getContext = function(type, opts){
    if (type === '2d') {
      if (this._noWRF === true || SKIP_WRF > 0) {
        // 黑名单或临时关闭：不干预
        return ORIG_GET.call(this, type, opts);
      }

      if (!opts || opts.willReadFrequently == null) {
        try { return ORIG_GET.call(this, type, Object.assign({}, opts, { willReadFrequently: true })); }
        catch(e) {}
      }
    }
    return ORIG_GET.call(this, type, opts);
  };

  // 2) 拉起一个“创建位图时跳过WRF”的作用域开关
  function withNoWRF(fn){
    SKIP_WRF++;
    try { return fn(); }
    finally { SKIP_WRF--; }
  }

  // 3) 让“接下来新建的 Bitmap”带上实例标记 _noWRF（以便 resize 等场景也能生效）
  var MARK_NO_WRF = 0;
  var _Bitmap_init = Bitmap.prototype.initialize;
  Bitmap.prototype.initialize = function(w, h){
    this._noWRF = !!this._noWRF || (MARK_NO_WRF > 0);
    return _Bitmap_init.apply(this, arguments);
  };

  function createBitmapsNoWRF(fn){
    MARK_NO_WRF++;
    try { return withNoWRF(fn); }    // 创建过程内的 getContext 也不加 WRF
    finally { MARK_NO_WRF--; }
  }

  // 4a) Terrax 遮罩：创建时进入“黑名单作用域”
  if (window.Lightmask && Lightmask.prototype && Lightmask.prototype._createBitmap) {
    var _createMask = Lightmask.prototype._createBitmap;
    Lightmask.prototype._createBitmap = function(){
      return createBitmapsNoWRF(_createMask.bind(this));
    };
  }

  // 4b) 窗口 contents（图标消失多半就是它被 WRF 了）：也进入黑名单
  if (Window_Base && Window_Base.prototype && Window_Base.prototype._createAllParts) {
    var _createAll = Window_Base.prototype._createAllParts;
    Window_Base.prototype._createAllParts = function(){
      return createBitmapsNoWRF(_createAll.bind(this));
    };
  }

  // 5) 保险：bitmap.resize 时重建的 canvas 也继承 _noWRF → 触发上面的 getContext 判定
  // （不需要再改 resize，本版 initialize 已给实例打了 _noWRF 标记）

})();

/* Terrax：遮罩降分辨率绘制 */
(function(){
  if (!Utils.isMobileDevice()) return;	
  if (!window.Lightmask || !Lightmask.prototype) return;
  var SCALE = 0.2;                  

  var _createBitmap = Lightmask.prototype._createBitmap;
  Lightmask.prototype._createBitmap = function(){
    _createBitmap.apply(this, arguments);
    if (this._maskBitmap && this.bitmap) {
      // 改位图像素尺寸
      var w = Math.max(1, Math.ceil(Graphics.width  * SCALE));
      var h = Math.max(1, Math.ceil(Graphics.height * SCALE));
      this._maskBitmap.resize(w, h);

      // 把显示精灵放大到原屏幕尺寸
      this.scale.x = 1 / SCALE;
      this.scale.y = 1 / SCALE;
    }
  };
})();
