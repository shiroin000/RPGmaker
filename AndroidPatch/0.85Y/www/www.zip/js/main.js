//=============================================================================
// main.js
//=============================================================================

(() => {
    const startTime = performance.now();
    const endTime = () => `${((performance.now() - startTime) / 1e3).toPrecision(3)}s`;

    const fragment = document.createDocumentFragment();

    let loadScript = (() => {
        const errorList = [];
        function createScript(src) {
            return new Promise(resolve => {
                fragment.appendChild(
                    Object.assign(document.createElement('script'), {
                        src,
                        async: false,
                        onload: resolve,
                        onerror: e => {
                            errorList.push(src);
                            resolve();
                        }
                    })
                )
            })
        };

        return {
            seq(list) {
                return new Promise((resolve, reject) => {
                    let src;
                    const tasks = [];
                    for (src of list) tasks.push(createScript(src));
                    document.head.appendChild(fragment);

                    Promise.allSettled(tasks).then(() => {
                        errorList.length > 0
                            ? reject("Failed to load path:\n" + errorList.join("\n"))
                            : resolve();
                    })
                })
            }
        }
    })();

    let init = (() => {
        const pixiList = [
            'js/libs/pixi.js',
            'js/libs/pixi-tilemap.js',
            'js/libs/pixi-picture.js',
        ];
        const otherList = [
            'js/libs/lz-string.js',
            'js/libs/iphone-inline-video.browser.js',
        ];
        const rpgCoreList = [
            'js/rpg_core.js',
            'js/rpg_managers.js',
            'js/rpg_objects.js',
            'js/rpg_scenes.js',
            'js/rpg_sprites.js',
            'js/rpg_windows.js',
            'js/rpg_custom.js',
            'js/plugins.js',
        ];

        const openCC = 'js/libs/opencc/full.min.js';

        /* Android */
        const cordova = 'cordova.js';
        const androidRun = 'js/run.js';

        function loadPlugins() {
            Object.assign(PluginManager, {
                scriptRecord: null,
                setup(plugins) {
                    this.scriptRecord = new Set(this._scripts);

                    let plugin;
                    const tasks = [];
                    for (plugin of plugins) {
                        if (plugin.status && !this.scriptRecord.has(plugin.name)) {
                            this.setParameters(plugin.name, plugin.parameters);
                            tasks.push(this.loadScript(plugin.name + '.js'));
                            this.scriptRecord.add(plugin.name);
                        }
                    }

                    document.head.appendChild(fragment);
                    this._scripts = [...this.scriptRecord];
                    this.scriptRecord.clear();

                    Promise.allSettled(tasks).then(() => {
                        SceneManager.run(Scene_Boot);
                        console.log('[OK] Init Complete', endTime());
                    })
                },
                loadScript(name) {
                    return new Promise(resolve => {
                        fragment.appendChild(
                            Object.assign(document.createElement('script'), {
                                src: this._path + name,
                                async: false,
                                onload: resolve,
                                onerror: e => {
                                    this._errorUrls.push(e.target._url);
                                    resolve();
                                },
                            })
                        )
                    })
                }
            });

            PluginManager.setup($plugins);
        };

        return {
            android() {
                function onDeviceReady() {
                    const root = cordova.file && cordova.file.dataDirectory;
                    if (!root || !window.resolveLocalFileSystemURL) {
                        console.error('cordova.file.dataDirectory or resolveLocalFileSystemURL not available');
                        return;
                    }

                    window.resolveLocalFileSystemURL(root, entry => {
                        try {
                            window.cdvUrl = (typeof entry.toInternalURL === 'function') ? entry.toInternalURL() : (entry.nativeURL || root);
                        } catch (e) {
                            window.cdvUrl = entry.nativeURL || root;
                        }

                        // ensure trailing slash
                        if (window.cdvUrl && !window.cdvUrl.endsWith('/')) window.cdvUrl += '/';
                        console.log('Global cdvUrl =', window.cdvUrl);

                        loadScript.seq([
                            cordova,
                            ...[
                                ...pixiList,
                                ...otherList,
                                ...rpgCoreList,
                            ].map(path => window.cdvUrl + path),
                            androidRun
                        ]).then(() => {
                            loadPlugins();
                            console.log('[OK] Android scripts loaded via seq', endTime());
                        }).catch(err => {
                            console.error('[ERR] Android seq load error:', err);
                        })

                    }, err => {
                        console.error('Error load FileEntry:', err);
                    });

                    loadScript = null;
                    init = null;
                }

                window.device
                    ? onDeviceReady()
                    : document.addEventListener('deviceready', onDeviceReady, { once: true });
            },
            // —— Desktop / NW.js —— 
            desktop() {
                loadScript.seq([...pixiList, ...otherList, openCC, ...rpgCoreList])
                    .then(() => {
                        loadPlugins();
                        console.log('[OK] Desktop scripts loaded', endTime());
                    }).catch(err => {
                        console.error(err);
                    }).finally(() => {
                        // 釋放閉包 GC
                        loadScript = null;
                        init = null;
                    })
            }
        }
    })();

    function isMobileDevice() {
        let isMobileDevice = false;
        if (navigator.userAgentData?.mobile != null) {
            isMobileDevice = navigator.userAgentData.mobile ? true : false;
        } else if (window.matchMedia?.('(max-width: 767px), (pointer: coarse)')?.matches) {
            isMobileDevice = true;
        } else if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
            isMobileDevice = true;
        }
        return isMobileDevice;
    };

    isMobileDevice()
        ? init.android()
        : init.desktop();
})();